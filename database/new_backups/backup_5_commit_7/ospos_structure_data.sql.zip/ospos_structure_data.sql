-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2023 at 04:47 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ospos`
--

-- --------------------------------------------------------

--
-- Table structure for table `ospos_app_config`
--

CREATE TABLE `ospos_app_config` (
  `key` varchar(50) NOT NULL,
  `value` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_app_config`
--

INSERT INTO `ospos_app_config` (`key`, `value`) VALUES
('address', '123 Nowhere street'),
('allow_duplicate_barcodes', '0'),
('barcode_content', 'id'),
('barcode_first_row', 'category'),
('barcode_font', 'Arial'),
('barcode_font_size', '10'),
('barcode_formats', '[]'),
('barcode_generate_if_empty', '0'),
('barcode_height', '50'),
('barcode_num_in_row', '2'),
('barcode_page_cellspacing', '20'),
('barcode_page_width', '100'),
('barcode_second_row', 'item_code'),
('barcode_third_row', 'unit_price'),
('barcode_type', 'Code39'),
('barcode_width', '250'),
('cash_decimals', '2'),
('cash_rounding_code', '1'),
('category_dropdown', '0'),
('company', 'Open Source Point of Sale'),
('company_logo', ''),
('country_codes', 'us'),
('currency_code', 'USD'),
('currency_decimals', '2'),
('currency_symbol', '$'),
('customer_reward_enable', '0'),
('dateformat', 'm/d/Y'),
('date_or_time_format', ''),
('default_receivings_discount', '0'),
('default_receivings_discount_type', '0'),
('default_register_mode', 'sale'),
('default_sales_discount', '0'),
('default_sales_discount_type', '0'),
('default_tax_1_name', ''),
('default_tax_1_rate', ''),
('default_tax_2_name', ''),
('default_tax_2_rate', ''),
('default_tax_category', '1'),
('default_tax_code', '2'),
('default_tax_jurisdiction', '1'),
('default_tax_rate', '8'),
('derive_sale_quantity', '0'),
('dinner_table_enable', '0'),
('email', 'changeme@example.com'),
('email_receipt_check_behaviour', 'last'),
('enforce_privacy', ''),
('fax', ''),
('financial_year', '1'),
('gcaptcha_enable', '0'),
('gcaptcha_secret_key', ''),
('gcaptcha_site_key', ''),
('giftcard_number', 'series'),
('image_allowed_types', 'jpg|gif|png'),
('image_max_height', '480'),
('image_max_size', '128'),
('image_max_width', '640'),
('include_hsn', '0'),
('invoice_default_comments', 'This is a default comment'),
('invoice_email_message', 'Dear {CU}, In attachment the receipt for sale {ISEQ}'),
('invoice_enable', '1'),
('invoice_type', 'invoice'),
('language', 'english'),
('language_code', 'en-US'),
('last_used_invoice_number', '0'),
('last_used_quote_number', '4'),
('last_used_work_order_number', '0'),
('lines_per_page', '25'),
('line_sequence', '0'),
('login_form', 'floating_labels'),
('mailpath', '/usr/sbin/sendmail'),
('msg_msg', ''),
('msg_pwd', ''),
('msg_src', ''),
('msg_uid', ''),
('multi_pack_enabled', '0'),
('notify_horizontal_position', 'center'),
('notify_vertical_position', 'bottom'),
('number_locale', 'en_US'),
('payment_options_order', 'cashdebitcredit'),
('phone', '555-555-5555'),
('print_bottom_margin', ''),
('print_delay_autoreturn', '0'),
('print_footer', '0'),
('print_header', '0'),
('print_left_margin', ''),
('print_receipt_check_behaviour', 'last'),
('print_right_margin', ''),
('print_silently', '0'),
('print_top_margin', ''),
('protocol', 'mail'),
('quantity_decimals', '0'),
('quote_default_comments', 'This is a default quote comment'),
('receipt_font_size', '12'),
('receipt_show_company_name', '1'),
('receipt_show_description', '1'),
('receipt_show_serialnumber', '1'),
('receipt_show_taxes', '1'),
('receipt_show_tax_ind', '0'),
('receipt_show_total_discount', '1'),
('receipt_template', 'receipt_default'),
('receiving_calculate_average_price', '0'),
('recv_invoice_format', '{CO}'),
('return_policy', 'Test'),
('sales_invoice_format', '{CO}'),
('sales_quote_format', 'Q%y{QSEQ:6}'),
('smtp_crypto', 'ssl'),
('smtp_host', ''),
('smtp_pass', ''),
('smtp_port', '465'),
('smtp_timeout', '5'),
('smtp_user', ''),
('suggestions_first_column', 'name'),
('suggestions_second_column', ''),
('suggestions_third_column', ''),
('tax_decimals', '2'),
('tax_id', 'vatid'),
('tax_included', '0'),
('theme', 'flatly'),
('thousands_separator', '1'),
('timeformat', 'H:i:s'),
('timezone', 'America/New_York'),
('use_destination_based_tax', '1'),
('website', ''),
('work_order_enable', '0'),
('work_order_format', 'W%y{WSEQ:6}');

-- --------------------------------------------------------

--
-- Table structure for table `ospos_attribute_definitions`
--

CREATE TABLE `ospos_attribute_definitions` (
  `definition_id` int(10) NOT NULL,
  `definition_name` varchar(255) NOT NULL,
  `definition_type` varchar(45) NOT NULL,
  `definition_unit` varchar(16) DEFAULT NULL,
  `definition_flags` tinyint(1) NOT NULL,
  `definition_fk` int(10) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_attribute_definitions`
--

INSERT INTO `ospos_attribute_definitions` (`definition_id`, `definition_name`, `definition_type`, `definition_unit`, `definition_flags`, `definition_fk`, `deleted`) VALUES
(-1, 'ospos_category', 'DROPDOWN', NULL, 0, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_attribute_links`
--

CREATE TABLE `ospos_attribute_links` (
  `attribute_id` int(11) DEFAULT NULL,
  `definition_id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `receiving_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ospos_attribute_values`
--

CREATE TABLE `ospos_attribute_values` (
  `attribute_id` int(11) NOT NULL,
  `attribute_value` varchar(255) DEFAULT NULL,
  `attribute_date` date DEFAULT NULL,
  `attribute_decimal` decimal(7,3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ospos_cash_up`
--

CREATE TABLE `ospos_cash_up` (
  `cashup_id` int(10) NOT NULL,
  `open_date` timestamp NULL DEFAULT current_timestamp(),
  `close_date` timestamp NULL DEFAULT NULL,
  `open_amount_cash` decimal(15,2) NOT NULL,
  `transfer_amount_cash` decimal(15,2) NOT NULL,
  `note` int(1) NOT NULL,
  `closed_amount_cash` decimal(15,2) NOT NULL,
  `closed_amount_card` decimal(15,2) NOT NULL,
  `closed_amount_check` decimal(15,2) NOT NULL,
  `closed_amount_total` decimal(15,2) NOT NULL,
  `description` varchar(255) NOT NULL,
  `open_employee_id` int(10) NOT NULL,
  `close_employee_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `closed_amount_due` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_cash_up`
--

INSERT INTO `ospos_cash_up` (`cashup_id`, `open_date`, `close_date`, `open_amount_cash`, `transfer_amount_cash`, `note`, `closed_amount_cash`, `closed_amount_card`, `closed_amount_check`, `closed_amount_total`, `description`, `open_employee_id`, `close_employee_id`, `deleted`, `closed_amount_due`) VALUES
(1, '2023-04-30 11:33:23', '2023-05-01 11:33:23', '300.00', '0.00', 0, '0.00', '0.00', '0.00', '-300.00', '', 1, 1, 0, '0.00'),
(2, '2023-06-09 07:39:24', '2023-06-09 07:39:24', '0.00', '0.00', 0, '0.00', '0.00', '0.00', '0.00', '', 1, 1, 0, '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `ospos_customers`
--

CREATE TABLE `ospos_customers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `taxable` tinyint(1) NOT NULL DEFAULT 1,
  `tax_id` varchar(32) NOT NULL DEFAULT '',
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `package_id` int(11) DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `employee_id` int(10) NOT NULL,
  `consent` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_customers`
--

INSERT INTO `ospos_customers` (`person_id`, `company_name`, `account_number`, `taxable`, `tax_id`, `sales_tax_code_id`, `discount`, `discount_type`, `package_id`, `points`, `deleted`, `date`, `employee_id`, `consent`) VALUES
(2, NULL, NULL, 1, '', NULL, '0.00', 0, NULL, NULL, 0, '2023-05-02 05:15:06', 1, 1),
(4, NULL, NULL, 1, '1122', NULL, '0.00', 0, NULL, NULL, 0, '2023-06-17 07:00:54', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_customers_packages`
--

CREATE TABLE `ospos_customers_packages` (
  `package_id` int(11) NOT NULL,
  `package_name` varchar(255) DEFAULT NULL,
  `points_percent` float NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_customers_packages`
--

INSERT INTO `ospos_customers_packages` (`package_id`, `package_name`, `points_percent`, `deleted`) VALUES
(1, 'Default', 0, 0),
(2, 'Bronze', 10, 0),
(3, 'Silver', 20, 0),
(4, 'Gold', 30, 0),
(5, 'Premium', 50, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_customers_points`
--

CREATE TABLE `ospos_customers_points` (
  `id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `points_earned` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ospos_dinner_tables`
--

CREATE TABLE `ospos_dinner_tables` (
  `dinner_table_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_dinner_tables`
--

INSERT INTO `ospos_dinner_tables` (`dinner_table_id`, `name`, `status`, `deleted`) VALUES
(1, 'Table 1', 0, 0),
(2, 'Take Away / Delivery', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_employees`
--

CREATE TABLE `ospos_employees` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `hash_version` tinyint(1) NOT NULL DEFAULT 2,
  `language` varchar(48) DEFAULT NULL,
  `language_code` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_employees`
--

INSERT INTO `ospos_employees` (`username`, `password`, `person_id`, `deleted`, `hash_version`, `language`, `language_code`) VALUES
('admin', '$2y$10$vJBSMlD02EC7ENSrKfVQXuvq9tNRHMtcOA8MSK2NYS748HHWm.gcG', 1, 0, 2, '', ''),
('useruser', '$2y$10$MjnXxo2sxTtR.QI1cLeIPuzHvIwXkHCFG1ghFwfHSJBdx6zIDKR8W', 3, 0, 2, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ospos_expenses`
--

CREATE TABLE `ospos_expenses` (
  `expense_id` int(10) NOT NULL,
  `date` timestamp NULL DEFAULT current_timestamp(),
  `amount` decimal(15,2) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `expense_category_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `employee_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `supplier_tax_code` varchar(255) DEFAULT NULL,
  `tax_amount` decimal(15,2) DEFAULT NULL,
  `supplier_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ospos_expense_categories`
--

CREATE TABLE `ospos_expense_categories` (
  `expense_category_id` int(10) NOT NULL,
  `category_name` varchar(255) DEFAULT NULL,
  `category_description` varchar(255) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_expense_categories`
--

INSERT INTO `ospos_expense_categories` (`expense_category_id`, `category_name`, `category_description`, `deleted`) VALUES
(1, 'cat2', 'qwqe', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_giftcards`
--

CREATE TABLE `ospos_giftcards` (
  `record_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `giftcard_id` int(11) NOT NULL,
  `giftcard_number` varchar(255) DEFAULT NULL,
  `value` decimal(15,2) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `person_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_giftcards`
--

INSERT INTO `ospos_giftcards` (`record_time`, `giftcard_id`, `giftcard_number`, `value`, `deleted`, `person_id`) VALUES
('2023-06-23 10:35:29', 1, '1200', '0.00', 0, 4);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_grants`
--

CREATE TABLE `ospos_grants` (
  `permission_id` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `menu_group` varchar(32) DEFAULT 'home'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_grants`
--

INSERT INTO `ospos_grants` (`permission_id`, `person_id`, `menu_group`) VALUES
('attributes', 1, 'office'),
('cashups', 1, 'home'),
('config', 1, 'office'),
('customers', 1, 'home'),
('employees', 1, 'office'),
('expenses', 1, 'home'),
('expenses_categories', 1, 'office'),
('giftcards', 1, 'home'),
('home', 1, 'office'),
('items', 1, 'home'),
('items_stock1', 1, '--'),
('items_stock1', 3, 'home'),
('items_stock2', 1, '--'),
('items_stock2', 3, 'home'),
('item_kits', 1, 'home'),
('messages', 1, 'home'),
('office', 1, 'home'),
('receivings', 1, 'home'),
('receivings_stock1', 1, '--'),
('receivings_stock1', 3, 'home'),
('receivings_stock2', 1, '--'),
('receivings_stock2', 3, 'home'),
('reports', 1, 'both'),
('reports_categories', 1, '--'),
('reports_customers', 1, '--'),
('reports_discounts', 1, '--'),
('reports_employees', 1, '--'),
('reports_expenses_categories', 1, '--'),
('reports_inventory', 1, '--'),
('reports_items', 1, '--'),
('reports_payments', 1, '--'),
('reports_receivings', 1, '--'),
('reports_sales', 1, '--'),
('reports_sales_taxes', 1, '--'),
('reports_suppliers', 1, '--'),
('reports_taxes', 1, '--'),
('sales', 1, 'home'),
('sales', 3, 'home'),
('sales_change_price', 1, '--'),
('sales_delete', 1, '--'),
('sales_delete', 3, '--'),
('sales_stock1', 1, '--'),
('sales_stock1', 3, 'home'),
('sales_stock2', 1, '--'),
('sales_stock2', 3, 'home'),
('suppliers', 1, 'home'),
('taxes', 1, 'office'),
('test', 1, 'both');

-- --------------------------------------------------------

--
-- Table structure for table `ospos_inventory`
--

CREATE TABLE `ospos_inventory` (
  `trans_id` int(11) NOT NULL,
  `trans_items` int(11) NOT NULL DEFAULT 0,
  `trans_user` int(11) NOT NULL DEFAULT 0,
  `trans_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `trans_comment` text NOT NULL,
  `trans_location` int(11) NOT NULL,
  `trans_inventory` decimal(15,3) NOT NULL DEFAULT 0.000
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_inventory`
--

INSERT INTO `ospos_inventory` (`trans_id`, `trans_items`, `trans_user`, `trans_date`, `trans_comment`, `trans_location`, `trans_inventory`) VALUES
(26, 1, 1, '2023-06-07 10:38:18', 'POS 20', 1, '1.000'),
(27, 3, 1, '2023-06-09 07:21:31', 'Manual Edit of Quantity', 1, '0.000'),
(28, 2, 1, '2023-06-09 07:26:38', '', 1, '3.000'),
(29, 2, 1, '2023-06-09 07:55:43', 'POS 22', 1, '-5.000'),
(30, 2, 1, '2023-06-09 07:57:42', 'POS 24', 1, '-3.000'),
(31, 2, 1, '2023-06-09 07:58:50', 'POS 25', 1, '-4.000'),
(32, 2, 1, '2023-06-09 08:00:07', 'POS 26', 1, '-6.000'),
(33, 2, 1, '2023-06-09 08:05:40', 'POS 27', 1, '-1.000'),
(34, 1, 1, '2023-06-11 10:43:35', 'POS 29', 1, '-1.000'),
(35, 2, 1, '2023-06-11 10:43:35', 'POS 29', 1, '-1.000'),
(36, 1, 1, '2023-06-12 05:11:44', 'POS 30', 1, '-1.000'),
(37, 2, 1, '2023-06-12 05:11:44', 'POS 30', 1, '-1.000'),
(38, 1, 1, '2023-06-12 06:41:56', 'RECV 2', 1, '10.000'),
(39, 1, 1, '2023-06-12 06:44:32', 'Manual Edit of Quantity', 1, '6.000'),
(40, 1, 3, '2023-06-12 09:10:17', 'POS 31', 1, '-1.000'),
(41, 2, 3, '2023-06-12 09:10:17', 'POS 31', 1, '-1.000'),
(42, 1, 1, '2023-06-12 09:15:46', 'Manual Edit of Quantity', 2, '33.000'),
(43, 1, 1, '2023-06-12 09:37:02', 'POS 32', 1, '-1.000'),
(44, 2, 1, '2023-06-12 09:37:02', 'POS 32', 2, '-1.000'),
(45, 4, 1, '2023-06-17 05:22:23', 'Manual Edit of Quantity', 1, '0.000'),
(46, 4, 1, '2023-06-17 05:22:23', 'Manual Edit of Quantity', 2, '0.000'),
(47, 2, 1, '2023-06-17 05:23:01', 'POS 33', 1, '-1.000'),
(48, 4, 1, '2023-06-17 05:23:01', 'POS 33', 1, '-1.000'),
(49, 4, 1, '2023-06-17 05:23:50', 'POS 34', 1, '-1.000'),
(50, 4, 1, '2023-06-17 05:23:50', 'POS 34', 1, '-1.000'),
(51, 2, 1, '2023-06-17 07:01:13', 'POS 36', 1, '-1.000'),
(52, 1, 1, '2023-06-17 07:18:05', 'POS 41', 1, '-1.000'),
(53, 2, 1, '2023-06-17 07:18:05', 'POS 41', 1, '-2.000'),
(54, 4, 1, '2023-06-17 08:14:02', 'Manual Edit of Quantity', 1, '63.000'),
(55, 5, 1, '2023-06-17 08:25:14', 'Manual Edit of Quantity', 1, '50.000'),
(56, 5, 1, '2023-06-17 08:25:14', 'Manual Edit of Quantity', 2, '0.000'),
(57, 1, 1, '2023-06-17 08:27:43', 'POS 42', 1, '-1.000'),
(58, 5, 1, '2023-06-17 08:33:23', 'POS 43', 1, '-3.000'),
(59, 4, 1, '2023-06-17 09:49:24', 'POS 44', 1, '-1.000'),
(60, 5, 1, '2023-06-17 09:49:24', 'POS 44', 1, '-1.000'),
(61, 1, 1, '2023-06-23 09:26:13', 'POS 45', 1, '-1.000'),
(62, 1, 1, '2023-06-23 09:33:35', 'Deleting sale 45', 1, '1.000'),
(63, 1, 1, '2023-06-23 09:36:13', 'POS 47', 1, '-1.000'),
(64, 1, 1, '2023-06-23 10:37:40', 'POS 48', 1, '-1.000'),
(21355, 1, 1, '2023-06-25 11:49:31', 'POS 52', 1, '-6.000'),
(21356, 1, 1, '2023-06-25 12:52:45', 'POS 53', 1, '-2.000'),
(21357, 1, 1, '2023-06-25 13:04:18', 'POS 54', 1, '-1.000'),
(21358, 2, 1, '2023-06-25 13:04:18', 'POS 54', 1, '-1.000'),
(21359, 1, 1, '2023-06-26 03:42:25', 'POS 55', 1, '-1.000'),
(21360, 2, 1, '2023-06-26 03:42:25', 'POS 55', 1, '-1.000'),
(21361, 4, 1, '2023-06-26 03:44:59', 'POS 56', 1, '-1.000'),
(21362, 5, 1, '2023-06-26 04:21:24', 'POS 57', 1, '-1.000'),
(21363, 1, 1, '2023-06-26 04:58:24', 'POS 58', 1, '-1.000'),
(21364, 2, 1, '2023-06-26 04:58:24', 'POS 58', 1, '-1.000'),
(21365, 1, 1, '2023-06-26 05:00:33', 'POS 59', 1, '-1.000'),
(21366, 2, 1, '2023-06-26 05:00:33', 'POS 59', 1, '-1.000'),
(21367, 2, 1, '2023-06-26 05:02:36', 'POS 60', 1, '-1.000');

-- --------------------------------------------------------

--
-- Table structure for table `ospos_items`
--

CREATE TABLE `ospos_items` (
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `item_number` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `cost_price` decimal(15,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `reorder_level` decimal(15,3) NOT NULL DEFAULT 0.000,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT 1.000,
  `item_id` int(10) NOT NULL,
  `pic_filename` varchar(255) DEFAULT NULL,
  `allow_alt_description` tinyint(1) NOT NULL,
  `is_serialized` tinyint(1) NOT NULL,
  `stock_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_type` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `tax_category_id` int(10) DEFAULT NULL,
  `qty_per_pack` decimal(15,3) NOT NULL DEFAULT 1.000,
  `pack_name` varchar(8) DEFAULT 'Each',
  `low_sell_item_id` int(10) DEFAULT 0,
  `hsn_code` varchar(32) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_items`
--

INSERT INTO `ospos_items` (`name`, `category`, `supplier_id`, `item_number`, `description`, `cost_price`, `unit_price`, `reorder_level`, `receiving_quantity`, `item_id`, `pic_filename`, `allow_alt_description`, `is_serialized`, `stock_type`, `item_type`, `deleted`, `tax_category_id`, `qty_per_pack`, `pack_name`, `low_sell_item_id`, `hsn_code`) VALUES
('cola', 'drinks', NULL, '1', '', '2.00', '4.00', '1.000', '1.000', 1, NULL, 0, 0, 0, 1, 0, NULL, '1.000', 'Each', 1, ''),
('cola', 'ww', NULL, '2', '', '1.00', '2.50', '1.000', '1.000', 2, NULL, 0, 0, 0, 0, 0, 0, '1.000', 'Each', 2, ''),
('pepsi_unstockable', 'ww', NULL, '3', '', '3.00', '4.00', '1.000', '1.000', 3, NULL, 0, 0, 1, 0, 0, 0, '1.000', 'Each', 3, ''),
('chips', 'sweets', NULL, '4', '', '1.00', '2.00', '1.000', '40.000', 4, NULL, 0, 0, 0, 0, 0, 2, '1.000', 'Each', 4, ''),
('soft drink1', 'sweets', NULL, '5', '', '1.30', '1.80', '1.000', '1.000', 5, NULL, 1, 0, 0, 0, 0, 1, '1.000', 'Each', 5, '');

-- --------------------------------------------------------

--
-- Table structure for table `ospos_items_taxes`
--

CREATE TABLE `ospos_items_taxes` (
  `item_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_items_taxes`
--

INSERT INTO `ospos_items_taxes` (`item_id`, `name`, `percent`) VALUES
(5, 'vat', '11.000');

-- --------------------------------------------------------

--
-- Table structure for table `ospos_item_kits`
--

CREATE TABLE `ospos_item_kits` (
  `item_kit_id` int(11) NOT NULL,
  `item_kit_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `kit_discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `kit_discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `price_option` tinyint(1) NOT NULL DEFAULT 0,
  `print_option` tinyint(1) NOT NULL DEFAULT 0,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ospos_item_kit_items`
--

CREATE TABLE `ospos_item_kit_items` (
  `item_kit_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL,
  `kit_sequence` int(3) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ospos_item_quantities`
--

CREATE TABLE `ospos_item_quantities` (
  `item_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL DEFAULT 0.000
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_item_quantities`
--

INSERT INTO `ospos_item_quantities` (`item_id`, `location_id`, `quantity`) VALUES
(1, 1, '0.000'),
(1, 2, '33.000'),
(2, 1, '-28.000'),
(2, 2, '-1.000'),
(3, 1, '0.000'),
(3, 2, '0.000'),
(4, 1, '58.000'),
(4, 2, '0.000'),
(5, 1, '45.000'),
(5, 2, '0.000');

-- --------------------------------------------------------

--
-- Table structure for table `ospos_migrations`
--

CREATE TABLE `ospos_migrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_migrations`
--

INSERT INTO `ospos_migrations` (`version`) VALUES
(20210714140000);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_modules`
--

CREATE TABLE `ospos_modules` (
  `name_lang_key` varchar(255) NOT NULL,
  `desc_lang_key` varchar(255) NOT NULL,
  `sort` int(10) NOT NULL,
  `module_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_modules`
--

INSERT INTO `ospos_modules` (`name_lang_key`, `desc_lang_key`, `sort`, `module_id`) VALUES
('module_attributes', 'module_attributes_desc', 107, 'attributes'),
('module_cashups', 'module_cashups_desc', 110, 'cashups'),
('module_config', 'module_config_desc', 900, 'config'),
('module_customers', 'module_customers_desc', 10, 'customers'),
('module_employees', 'module_employees_desc', 80, 'employees'),
('module_expenses', 'module_expenses_desc', 108, 'expenses'),
('module_expenses_categories', 'module_expenses_categories_desc', 109, 'expenses_categories'),
('module_giftcards', 'module_giftcards_desc', 90, 'giftcards'),
('module_home', 'module_home_desc', 1, 'home'),
('module_items', 'module_items_desc', 20, 'items'),
('module_item_kits', 'module_item_kits_desc', 30, 'item_kits'),
('module_messages', 'module_messages_desc', 98, 'messages'),
('module_office', 'module_office_desc', 999, 'office'),
('module_receivings', 'module_receivings_desc', 60, 'receivings'),
('module_reports', 'module_reports_desc', 50, 'reports'),
('module_sales', 'module_sales_desc', 70, 'sales'),
('module_suppliers', 'module_suppliers_desc', 40, 'suppliers'),
('module_taxes', 'module_taxes_desc', 105, 'taxes'),
('module_test', 'module_test_desc', 200, 'test');

-- --------------------------------------------------------

--
-- Table structure for table `ospos_people`
--

CREATE TABLE `ospos_people` (
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` int(1) DEFAULT NULL,
  `phone_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address_1` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `comments` text NOT NULL,
  `person_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_people`
--

INSERT INTO `ospos_people` (`first_name`, `last_name`, `gender`, `phone_number`, `email`, `address_1`, `address_2`, `city`, `state`, `zip`, `country`, `comments`, `person_id`) VALUES
('John', 'Doe', NULL, '555-555-5555', 'changeme@example.com', 'Address 1', '', '', '', '', '', '', 1),
('Dawoud', 'Tormos', 1, '8282282', 'asda@gmail.com', '', '', '', '', '', '', '', 2),
('Employee', '2', 1, '', '', '', '', '', '', '', '', '', 3),
('Zboun', '5ara', 1, '', '', '', '', '', '', '', '', '', 4);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_permissions`
--

CREATE TABLE `ospos_permissions` (
  `permission_id` varchar(255) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  `location_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_permissions`
--

INSERT INTO `ospos_permissions` (`permission_id`, `module_id`, `location_id`) VALUES
('attributes', 'attributes', NULL),
('cashups', 'cashups', NULL),
('config', 'config', NULL),
('customers', 'customers', NULL),
('employees', 'employees', NULL),
('expenses', 'expenses', NULL),
('expenses_categories', 'expenses_categories', NULL),
('giftcards', 'giftcards', NULL),
('home', 'home', NULL),
('items', 'items', NULL),
('items_stock1', 'items', 1),
('items_stock2', 'items', 2),
('item_kits', 'item_kits', NULL),
('messages', 'messages', NULL),
('office', 'office', NULL),
('receivings', 'receivings', NULL),
('receivings_stock1', 'receivings', 1),
('receivings_stock2', 'receivings', 2),
('reports', 'reports', NULL),
('reports_categories', 'reports', NULL),
('reports_customers', 'reports', NULL),
('reports_discounts', 'reports', NULL),
('reports_employees', 'reports', NULL),
('reports_expenses_categories', 'reports', NULL),
('reports_inventory', 'reports', NULL),
('reports_items', 'reports', NULL),
('reports_payments', 'reports', NULL),
('reports_receivings', 'reports', NULL),
('reports_sales', 'reports', NULL),
('reports_sales_taxes', 'reports', NULL),
('reports_suppliers', 'reports', NULL),
('reports_taxes', 'reports', NULL),
('sales', 'sales', NULL),
('sales_change_price', 'sales', NULL),
('sales_delete', 'sales', NULL),
('sales_stock1', 'sales', 1),
('sales_stock2', 'sales', 2),
('suppliers', 'suppliers', NULL),
('taxes', 'taxes', NULL),
('test', 'test', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_receivings`
--

CREATE TABLE `ospos_receivings` (
  `receiving_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `supplier_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `receiving_id` int(10) NOT NULL,
  `payment_type` varchar(20) DEFAULT NULL,
  `reference` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_receivings`
--

INSERT INTO `ospos_receivings` (`receiving_time`, `supplier_id`, `employee_id`, `comment`, `receiving_id`, `payment_type`, `reference`) VALUES
('2023-04-30 11:44:58', NULL, 1, '', 1, 'Cash', NULL),
('2023-06-12 06:41:56', NULL, 1, '', 2, 'Cash', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_receivings_items`
--

CREATE TABLE `ospos_receivings_items` (
  `receiving_id` int(10) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `description` varchar(30) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT 0.000,
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_location` int(11) NOT NULL,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT 1.000
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_receivings_items`
--

INSERT INTO `ospos_receivings_items` (`receiving_id`, `item_id`, `description`, `serialnumber`, `line`, `quantity_purchased`, `item_cost_price`, `item_unit_price`, `discount`, `discount_type`, `item_location`, `receiving_quantity`) VALUES
(1, 1, '', NULL, 1, '10.000', '0.00', '1.00', '0.00', 0, 1, '1.000'),
(2, 1, '', NULL, 1, '10.000', '2.00', '3.00', '0.00', 0, 1, '1.000');

-- --------------------------------------------------------

--
-- Table structure for table `ospos_sales`
--

CREATE TABLE `ospos_sales` (
  `sale_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `customer_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `invoice_number` varchar(32) DEFAULT NULL,
  `quote_number` varchar(32) DEFAULT NULL,
  `sale_id` int(10) NOT NULL,
  `sale_status` tinyint(1) NOT NULL DEFAULT 0,
  `dinner_table_id` int(11) DEFAULT NULL,
  `work_order_number` varchar(32) DEFAULT NULL,
  `sale_type` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_sales`
--

INSERT INTO `ospos_sales` (`sale_time`, `customer_id`, `employee_id`, `comment`, `invoice_number`, `quote_number`, `sale_id`, `sale_status`, `dinner_table_id`, `work_order_number`, `sale_type`) VALUES
('2023-04-30 11:25:24', NULL, 1, '', '22', NULL, 1, 2, NULL, NULL, 0),
('2023-04-30 11:37:08', NULL, 1, '', NULL, NULL, 2, 2, NULL, NULL, 0),
('2023-04-30 11:39:44', NULL, 1, '', NULL, NULL, 3, 2, NULL, NULL, 4),
('2023-04-30 11:40:57', NULL, 1, '', NULL, NULL, 4, 2, NULL, NULL, 4),
('2023-04-30 11:47:55', NULL, 1, '', NULL, NULL, 5, 0, NULL, NULL, 0),
('2023-04-30 11:49:39', NULL, 1, '', NULL, NULL, 6, 0, NULL, NULL, 0),
('2023-05-01 09:44:32', NULL, 1, '', NULL, NULL, 7, 0, NULL, NULL, 0),
('2023-05-01 09:49:20', NULL, 1, '', NULL, NULL, 8, 0, NULL, NULL, 4),
('2023-05-02 05:13:12', NULL, 1, '', NULL, NULL, 9, 0, NULL, NULL, 0),
('2023-05-02 09:56:40', NULL, 1, '', NULL, NULL, 10, 0, NULL, NULL, 0),
('2023-06-07 10:21:08', NULL, 1, '', NULL, NULL, 11, 0, NULL, NULL, 0),
('2023-06-07 10:21:46', NULL, 1, '', NULL, NULL, 12, 0, NULL, NULL, 0),
('2023-06-07 10:22:28', 2, 1, '', NULL, NULL, 13, 0, NULL, NULL, 0),
('2023-06-07 10:28:10', NULL, 1, '', NULL, NULL, 14, 0, NULL, NULL, 0),
('2023-06-07 10:31:11', NULL, 1, '', NULL, NULL, 15, 0, NULL, NULL, 4),
('2023-06-07 10:33:50', NULL, 1, '', NULL, NULL, 17, 0, NULL, NULL, 4),
('2023-06-07 10:35:50', NULL, 1, '', NULL, NULL, 18, 0, NULL, NULL, 0),
('2023-06-07 10:36:21', NULL, 1, '', NULL, NULL, 19, 0, NULL, NULL, 4),
('2023-06-07 10:38:18', NULL, 1, '', NULL, NULL, 20, 0, NULL, NULL, 4),
('2023-06-09 07:23:48', NULL, 1, '', NULL, NULL, 21, 0, NULL, NULL, 0),
('2023-06-09 07:55:43', NULL, 1, '', NULL, NULL, 22, 0, NULL, NULL, 0),
('2023-06-09 07:54:51', NULL, 1, '', NULL, NULL, 23, 1, NULL, NULL, 0),
('2023-06-09 07:57:42', NULL, 1, '', NULL, NULL, 24, 0, NULL, NULL, 0),
('2023-06-09 07:58:50', NULL, 1, '', NULL, NULL, 25, 0, NULL, NULL, 0),
('2023-06-09 08:00:07', NULL, 1, '', NULL, NULL, 26, 0, NULL, NULL, 0),
('2023-06-09 08:05:40', NULL, 1, '', NULL, NULL, 27, 0, NULL, NULL, 0),
('2023-06-09 10:04:35', NULL, 1, '', NULL, NULL, 28, 0, NULL, NULL, 4),
('2023-06-11 10:43:35', NULL, 1, '', NULL, NULL, 29, 0, NULL, NULL, 0),
('2023-06-12 05:11:44', NULL, 1, '', NULL, NULL, 30, 0, NULL, NULL, 0),
('2023-06-12 09:10:17', NULL, 3, '', NULL, NULL, 31, 0, NULL, NULL, 0),
('2023-06-12 09:37:02', NULL, 1, '', NULL, NULL, 32, 0, 1, NULL, 0),
('2023-06-17 05:23:01', NULL, 1, '', NULL, NULL, 33, 0, NULL, NULL, 0),
('2023-06-17 05:23:50', NULL, 1, '', NULL, NULL, 34, 0, NULL, NULL, 0),
('2023-06-17 06:59:53', NULL, 1, '', NULL, NULL, 35, 1, NULL, NULL, 0),
('2023-06-17 07:01:13', 4, 1, '', NULL, NULL, 36, 0, NULL, NULL, 0),
('2023-06-17 07:10:49', 4, 1, '', NULL, 'Q23000001', 37, 1, NULL, NULL, 3),
('2023-06-17 07:12:08', 4, 1, '', NULL, 'Q23000002', 38, 2, NULL, NULL, 3),
('2023-06-17 07:16:10', 4, 1, '', NULL, 'Q23000003', 39, 1, NULL, NULL, 3),
('2023-06-17 07:16:57', 4, 1, 'gkgkgjkgkgj', NULL, 'Q23000004', 40, 1, NULL, NULL, 3),
('2023-06-17 07:18:05', 4, 1, '', '1', NULL, 41, 0, NULL, NULL, 1),
('2023-06-17 08:27:43', NULL, 1, '', NULL, NULL, 42, 0, NULL, NULL, 0),
('2023-06-17 08:33:23', NULL, 1, '', NULL, NULL, 43, 0, NULL, NULL, 0),
('2023-06-17 09:49:24', 4, 1, '', NULL, NULL, 44, 0, NULL, NULL, 0),
('2023-06-23 09:26:13', 4, 1, '', NULL, NULL, 45, 2, NULL, NULL, 0),
('2023-06-23 09:35:37', NULL, 1, '', NULL, NULL, 46, 1, NULL, NULL, 0),
('2023-06-23 09:36:13', 4, 1, '', NULL, NULL, 47, 0, NULL, NULL, 0),
('2023-06-23 10:37:40', 4, 1, '', NULL, NULL, 48, 0, NULL, NULL, 0),
('2023-06-23 11:31:41', NULL, 1, '', NULL, NULL, 49, 0, NULL, NULL, 0),
('2023-06-23 11:34:26', NULL, 1, '', NULL, NULL, 50, 0, NULL, NULL, 0),
('2023-06-25 11:01:05', NULL, 1, '', NULL, NULL, 51, 0, NULL, NULL, 0),
('2023-06-25 11:49:31', NULL, 1, '', NULL, NULL, 52, 0, NULL, NULL, 0),
('2023-06-25 12:52:45', NULL, 1, '', NULL, NULL, 53, 0, NULL, NULL, 0),
('2023-06-25 13:04:18', 4, 1, '', NULL, NULL, 54, 0, NULL, NULL, 0),
('2023-06-26 03:42:25', 4, 1, '', NULL, NULL, 55, 0, NULL, NULL, 0),
('2023-06-26 03:44:59', NULL, 1, '', NULL, NULL, 56, 0, NULL, NULL, 0),
('2023-06-26 04:21:24', NULL, 1, '', NULL, NULL, 57, 0, NULL, NULL, 0),
('2023-06-26 04:58:24', NULL, 1, '', NULL, NULL, 58, 0, NULL, NULL, 0),
('2023-06-26 05:00:33', 4, 1, '', NULL, NULL, 59, 0, NULL, NULL, 0),
('2023-06-26 05:02:36', NULL, 1, '', NULL, NULL, 60, 0, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_sales_items`
--

CREATE TABLE `ospos_sales_items` (
  `sale_id` int(10) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `description` varchar(255) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL DEFAULT 0,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT 0.000,
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_location` int(11) NOT NULL,
  `print_option` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_sales_items`
--

INSERT INTO `ospos_sales_items` (`sale_id`, `item_id`, `description`, `serialnumber`, `line`, `quantity_purchased`, `item_cost_price`, `item_unit_price`, `discount`, `discount_type`, `item_location`, `print_option`) VALUES
(1, 1, '', '', 1, '2.000', '0.00', '4.00', '-10.00', 0, 1, 0),
(2, 1, '', '', 1, '10.000', '0.00', '4.00', '0.00', 0, 1, 0),
(3, 1, '', '', 1, '20.000', '0.00', '4.00', '0.00', 0, 1, 0),
(4, 1, '', '', 1, '-10.000', '0.00', '4.00', '0.00', 0, 1, 0),
(5, 1, '', '', 1, '13.000', '0.00', '4.00', '0.00', 0, 1, 0),
(6, 1, '', '', 1, '10.000', '2.00', '4.00', '0.00', 0, 1, 0),
(7, 1, '', '', 1, '15.000', '2.00', '4.00', '0.00', 0, 1, 0),
(8, 1, '', '', 1, '-5.000', '2.00', '3.00', '0.00', 0, 1, 0),
(9, 1, '', '', 1, '5.000', '2.00', '4.00', '0.00', 0, 1, 0),
(10, 1, '', '', 1, '1.000', '2.00', '4.00', '0.00', 0, 1, 0),
(11, 1, '', '', 1, '3.000', '2.00', '4.00', '0.00', 0, 1, 0),
(12, 1, '', '', 1, '4.000', '2.00', '4.00', '0.00', 0, 1, 0),
(13, 1, '', '', 1, '1.000', '2.00', '4.00', '0.00', 0, 1, 0),
(14, 1, '', '', 1, '2.000', '2.00', '4.00', '0.00', 0, 1, 0),
(15, 1, '', '', 1, '3.000', '2.00', '4.00', '0.00', 0, 1, 0),
(17, 1, '', '', 1, '-4.000', '2.00', '4.00', '0.00', 0, 1, 0),
(18, 1, '', '', 1, '1.000', '2.00', '8.00', '0.00', 0, 1, 0),
(19, 1, '', '', 1, '-1.000', '2.00', '4.00', '0.00', 0, 1, 0),
(20, 1, '', '', 1, '-1.000', '2.00', '8.00', '0.00', 0, 1, 0),
(21, 3, '', '', 1, '8.000', '3.00', '4.00', '0.00', 0, 1, 0),
(22, 2, '', '', 1, '5.000', '1.00', '2.00', '0.00', 0, 1, 0),
(22, 3, '', '', 2, '3.000', '3.00', '4.00', '0.00', 0, 1, 0),
(23, 2, '', '', 1, '2.000', '1.00', '2.00', '0.00', 0, 1, 0),
(24, 2, '', '', 1, '3.000', '1.00', '2.00', '0.00', 0, 1, 0),
(25, 2, '', '', 1, '4.000', '1.00', '2.00', '0.00', 0, 1, 0),
(26, 2, '', '', 1, '6.000', '1.00', '2.00', '0.00', 0, 1, 0),
(27, 2, '', '', 1, '1.000', '1.00', '2.00', '0.00', 0, 1, 0),
(27, 3, '', '', 2, '1.000', '3.00', '4.00', '0.00', 0, 1, 0),
(28, 3, '', '', 1, '-8.000', '3.00', '4.00', '0.00', 0, 1, 0),
(29, 1, '', '', 1, '1.000', '2.00', '4.00', '0.00', 0, 1, 0),
(29, 2, '', '', 2, '1.000', '1.00', '2.00', '0.00', 0, 1, 0),
(29, 3, '', '', 3, '2.000', '3.00', '4.00', '0.00', 0, 1, 0),
(30, 1, '', '', 1, '1.000', '2.00', '4.00', '0.00', 0, 1, 0),
(30, 2, '', '', 2, '1.000', '1.00', '2.00', '0.00', 0, 1, 0),
(30, 3, '', '', 3, '1.000', '3.00', '4.00', '0.00', 0, 1, 0),
(31, 1, '', '', 1, '1.000', '0.00', '4.00', '0.00', 0, 1, 0),
(31, 2, '', '', 2, '1.000', '1.00', '2.00', '0.00', 0, 1, 0),
(31, 3, '', '', 3, '1.000', '3.00', '4.00', '0.00', 0, 1, 0),
(32, 1, '', '', 1, '1.000', '0.00', '4.00', '0.00', 0, 1, 0),
(32, 2, '', '', 3, '1.000', '1.00', '2.00', '0.00', 0, 2, 0),
(32, 3, '', '', 2, '1.000', '3.00', '4.00', '0.00', 0, 2, 0),
(33, 2, '', '', 1, '1.000', '1.00', '2.50', '0.00', 0, 1, 0),
(33, 4, '', '', 2, '1.000', '1.00', '2.00', '0.00', 0, 1, 0),
(34, 4, '', '2332', 1, '1.000', '1.00', '2.00', '0.00', 0, 1, 0),
(34, 4, '', '2332', 2, '1.000', '1.00', '2.00', '0.00', 0, 1, 0),
(35, 2, '', '', 1, '1.000', '1.00', '2.50', '0.00', 0, 1, 0),
(35, 3, '', '', 2, '1.000', '3.00', '4.00', '0.00', 0, 1, 0),
(36, 2, '', '', 1, '1.000', '1.00', '2.50', '0.00', 0, 1, 0),
(36, 3, '', '', 2, '2.000', '3.00', '4.00', '0.00', 0, 1, 0),
(37, 1, '', '', 1, '1.000', '2.00', '4.00', '0.00', 0, 1, 0),
(37, 2, '', '', 2, '1.000', '1.00', '2.50', '0.00', 0, 1, 0),
(38, 1, '', '', 1, '5.000', '2.00', '4.00', '0.00', 0, 1, 0),
(38, 2, '', '', 3, '1.000', '1.00', '2.50', '0.00', 0, 1, 0),
(38, 3, '', '', 2, '1.000', '3.00', '4.00', '0.00', 0, 1, 0),
(39, 1, '', '', 1, '1.000', '2.00', '4.00', '0.00', 0, 1, 0),
(39, 2, '', '', 2, '1.000', '1.00', '2.50', '0.00', 0, 1, 0),
(40, 1, '', '', 1, '1.000', '2.00', '4.00', '0.00', 0, 1, 0),
(40, 2, '', '', 2, '1.000', '1.00', '2.50', '0.00', 0, 1, 0),
(41, 1, '', '', 1, '1.000', '2.00', '4.00', '0.00', 0, 1, 0),
(41, 2, '', '', 2, '2.000', '1.00', '2.50', '0.00', 0, 1, 0),
(41, 3, '', '', 3, '2.000', '3.00', '4.00', '0.00', 0, 1, 0),
(42, 1, '', '', 1, '1.000', '2.00', '4.00', '0.00', 0, 1, 0),
(43, 3, '', '', 1, '20.000', '3.00', '4.00', '0.00', 0, 1, 0),
(43, 5, '', '', 2, '3.000', '1.50', '2.25', '0.00', 0, 1, 0),
(44, 4, '', '', 1, '1.000', '1.00', '2.00', '0.00', 0, 1, 0),
(44, 5, '', '', 2, '1.000', '1.50', '2.25', '0.00', 0, 1, 0),
(45, 1, '', '', 1, '1.000', '2.00', '4.00', '0.00', 0, 1, 0),
(46, 1, '', '', 1, '1.000', '2.00', '4.00', '0.00', 0, 1, 0),
(47, 1, '', '', 1, '1.000', '2.00', '4.00', '0.00', 0, 1, 0),
(48, 1, '', '', 1, '1.000', '2.00', '4.00', '0.00', 0, 1, 0),
(49, 3, '', '', 1, '1.000', '3.00', '4.00', '0.00', 0, 1, 0),
(50, 3, '', '', 1, '2.000', '3.00', '4.00', '0.00', 0, 1, 0),
(51, 1, '', '', 1, '2.000', '2.00', '4.00', '0.00', 0, 1, 0),
(52, 1, '', '', 1, '6.000', '2.00', '4.00', '0.00', 0, 1, 0),
(53, 1, '', '', 1, '2.000', '2.00', '4.00', '0.00', 0, 1, 0),
(54, 1, '', '', 1, '1.000', '2.00', '4.00', '0.00', 0, 1, 0),
(54, 2, '', '', 2, '1.000', '1.00', '2.50', '0.00', 0, 1, 0),
(54, 3, '', '', 3, '5.000', '3.00', '4.00', '0.00', 0, 1, 0),
(55, 1, '', '', 1, '1.000', '2.00', '4.00', '0.00', 0, 1, 0),
(55, 2, '', '', 2, '1.000', '1.00', '2.50', '0.00', 0, 1, 0),
(55, 3, '', '', 3, '1.000', '3.00', '4.00', '0.00', 0, 1, 0),
(56, 4, '', '', 1, '1.000', '1.00', '2.00', '0.00', 0, 1, 0),
(57, 5, '', '', 1, '1.000', '1.30', '1.80', '0.00', 0, 1, 0),
(58, 1, '', '', 1, '1.000', '2.00', '4.00', '0.00', 0, 1, 0),
(58, 2, '', '', 2, '1.000', '1.00', '2.50', '0.00', 0, 1, 0),
(59, 1, '', '', 1, '1.000', '2.00', '4.00', '0.00', 0, 1, 0),
(59, 2, '', '', 2, '1.000', '1.00', '2.50', '0.00', 0, 1, 0),
(59, 3, '', '', 3, '1.000', '3.00', '4.00', '0.00', 0, 1, 0),
(60, 2, '', '', 2, '1.000', '1.00', '2.50', '0.00', 0, 1, 0),
(60, 3, '', '', 1, '1.000', '3.00', '4.00', '0.00', 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_sales_items_taxes`
--

CREATE TABLE `ospos_sales_items_taxes` (
  `sale_id` int(10) NOT NULL,
  `item_id` int(10) NOT NULL,
  `line` int(3) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `tax_type` tinyint(1) NOT NULL DEFAULT 0,
  `rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  `cascade_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `item_tax_amount` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `jurisdiction_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_sales_items_taxes`
--

INSERT INTO `ospos_sales_items_taxes` (`sale_id`, `item_id`, `line`, `name`, `percent`, `tax_type`, `rounding_code`, `cascade_sequence`, `item_tax_amount`, `sales_tax_code_id`, `jurisdiction_id`, `tax_category_id`) VALUES
(43, 5, 2, 'vat', '11.0000', 1, 1, 0, '0.7400', NULL, NULL, NULL),
(44, 4, 1, 'VAT_I', '11.0000', 0, 1, 0, '0.1982', 2, 2, 2),
(44, 5, 2, 'VAT_E', '11.0000', 1, 1, 0, '0.2500', 2, 1, 1),
(51, 1, 1, 'VAT_E', '11.0000', 1, 1, 0, '0.8800', 2, 1, 1),
(52, 1, 1, 'VAT_E', '11.0000', 1, 1, 0, '2.6400', 2, 1, 1),
(53, 1, 1, 'VAT_E', '11.0000', 1, 1, 0, '0.8800', 2, 1, 1),
(54, 1, 1, 'VAT_E', '11.0000', 1, 1, 0, '0.4400', 2, 1, 1),
(55, 1, 1, 'VAT_E', '11.0000', 1, 1, 0, '0.4400', 2, 1, 1),
(56, 4, 1, 'VAT_I', '11.0000', 0, 1, 0, '0.1982', 2, 2, 2),
(57, 5, 1, 'VAT_E', '11.0000', 1, 1, 0, '0.2000', 2, 1, 1),
(58, 1, 1, 'VAT_E', '11.0000', 1, 1, 0, '0.4400', 2, 1, 1),
(59, 1, 1, 'VAT_E', '11.0000', 1, 1, 0, '0.4400', 2, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_sales_payments`
--

CREATE TABLE `ospos_sales_payments` (
  `payment_id` int(11) NOT NULL,
  `sale_id` int(10) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `payment_amount` decimal(15,2) NOT NULL,
  `cash_refund` decimal(15,2) NOT NULL DEFAULT 0.00,
  `cash_adjustment` tinyint(4) NOT NULL DEFAULT 0,
  `employee_id` int(11) DEFAULT NULL,
  `payment_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `reference_code` varchar(40) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_sales_payments`
--

INSERT INTO `ospos_sales_payments` (`payment_id`, `sale_id`, `payment_type`, `payment_amount`, `cash_refund`, `cash_adjustment`, `employee_id`, `payment_time`, `reference_code`) VALUES
(1, 1, 'Cash', '8.80', '0.00', 0, 1, '2023-04-30 18:25:24', ''),
(2, 2, 'Cash', '40.00', '0.00', 0, 1, '2023-04-30 18:37:08', ''),
(3, 4, 'Cash', '-40.00', '0.00', 0, 1, '2023-04-30 18:40:57', ''),
(4, 5, 'Cash', '52.00', '0.00', 0, 1, '2023-04-30 18:47:55', ''),
(5, 6, 'Cash', '40.00', '0.00', 0, 1, '2023-04-30 18:49:39', ''),
(6, 7, 'Cash', '60.00', '0.00', 0, 1, '2023-05-01 16:44:33', ''),
(7, 8, 'Cash', '-15.00', '0.00', 0, 1, '2023-05-01 16:49:20', ''),
(8, 9, 'Cash', '20.00', '0.00', 0, 1, '2023-05-02 12:13:12', ''),
(9, 10, 'Cash', '4.00', '0.00', 0, 1, '2023-05-02 16:56:40', ''),
(10, 11, 'Cash', '12.00', '0.00', 0, 1, '2023-06-07 17:21:08', ''),
(11, 12, 'Cash', '16.00', '0.00', 0, 1, '2023-06-07 17:21:46', ''),
(12, 13, 'Cash', '4.00', '0.00', 0, 1, '2023-06-07 17:22:28', ''),
(13, 14, 'Cash', '8.00', '0.00', 0, 1, '2023-06-07 17:28:10', ''),
(14, 17, 'Cash', '-16.00', '0.00', 0, 1, '2023-06-07 17:33:50', ''),
(15, 18, 'Cash', '8.00', '0.00', 0, 1, '2023-06-07 17:35:50', ''),
(16, 19, 'Cash', '-4.00', '0.00', 0, 1, '2023-06-07 17:36:21', ''),
(17, 20, 'Cash', '-8.00', '0.00', 0, 1, '2023-06-07 17:38:18', ''),
(18, 21, 'Cash', '32.00', '0.00', 0, 1, '2023-06-09 14:23:48', ''),
(19, 22, 'Cash', '22.00', '0.00', 0, 1, '2023-06-09 14:55:43', ''),
(20, 25, 'Cash', '8.00', '0.00', 0, 1, '2023-06-09 14:58:50', ''),
(21, 26, 'Cash', '12.00', '0.00', 0, 1, '2023-06-09 15:00:07', ''),
(22, 27, 'Cash', '6.00', '0.00', 0, 1, '2023-06-09 15:05:40', ''),
(23, 28, 'Cash', '-32.00', '0.00', 0, 1, '2023-06-09 17:04:35', ''),
(24, 29, 'Debit Card', '10.00', '0.00', 0, 1, '2023-06-11 17:43:35', ''),
(25, 29, 'Cash', '4.00', '0.00', 0, 1, '2023-06-11 17:43:35', ''),
(26, 30, 'Cash', '6.00', '0.00', 0, 1, '2023-06-12 12:11:44', ''),
(27, 30, 'Debit Card', '4.00', '0.00', 0, 1, '2023-06-12 12:11:44', ''),
(28, 31, 'Cash', '10.00', '0.00', 0, 3, '2023-06-12 16:10:17', ''),
(29, 32, 'Cash', '10.00', '0.00', 0, 1, '2023-06-12 16:37:02', ''),
(30, 33, 'Cash', '4.50', '0.00', 0, 1, '2023-06-17 12:23:01', ''),
(31, 34, 'Cash', '4.00', '0.00', 0, 1, '2023-06-17 12:23:50', ''),
(32, 36, 'Cash', '10.50', '0.00', 0, 1, '2023-06-17 14:01:13', ''),
(33, 37, 'Cash', '6.50', '0.00', 0, 1, '2023-06-17 14:10:49', ''),
(34, 38, 'Cash', '26.50', '0.00', 0, 1, '2023-06-17 14:12:08', ''),
(35, 41, 'Cash', '17.00', '0.00', 0, 1, '2023-06-17 14:19:27', ''),
(36, 42, 'Cash', '4.00', '0.00', 0, 1, '2023-06-17 15:27:43', ''),
(37, 43, 'Cash', '87.49', '0.00', 0, 1, '2023-06-17 15:33:23', ''),
(38, 44, 'Cash', '4.50', '0.00', 0, 1, '2023-06-17 16:49:24', ''),
(39, 45, 'مستحق', '4.00', '0.00', 0, 1, '2023-06-23 16:26:13', ''),
(40, 46, 'مستحق', '4.00', '0.00', 0, 1, '2023-06-23 16:35:37', ''),
(41, 47, 'نقدى', '4.00', '0.00', 0, 1, '2023-06-23 16:36:13', ''),
(42, 48, 'بطاقة هدية:1200', '3.00', '0.00', 0, 1, '2023-06-23 17:37:40', ''),
(43, 48, 'نقدى', '1.00', '0.00', 0, 1, '2023-06-23 17:37:40', ''),
(44, 49, 'نقدى', '8.70', '4.70', 0, 1, '2023-06-23 18:31:41', ''),
(46, 50, 'نقدى', '108.70', '100.70', 0, 1, '2023-06-23 18:34:26', ''),
(47, 51, 'Cash', '8.88', '0.00', 0, 1, '2023-06-25 18:01:05', ''),
(48, 52, 'Cash', '26.64', '0.00', 0, 1, '2023-06-25 18:49:31', ''),
(49, 53, 'Cash', '6666.00', '6657.12', 0, 1, '2023-06-25 19:52:45', ''),
(50, 54, 'Cash', '5.20', '0.00', 0, 1, '2023-06-25 20:04:18', ''),
(51, 54, 'Cash', '21.74', '0.00', 0, 1, '2023-06-25 20:04:18', ''),
(52, 55, 'Cash', '9.78', '0.00', 0, 1, '2023-06-26 10:42:25', ''),
(53, 55, 'Cash', '1.16', '0.00', 0, 1, '2023-06-26 10:42:25', ''),
(54, 56, 'Cash', '2.00', '0.00', 0, 1, '2023-06-26 10:44:59', ''),
(55, 57, 'Cash', '2.00', '0.00', 0, 1, '2023-06-26 11:21:24', ''),
(56, 58, 'Cash', '20.00', '13.06', 0, 1, '2023-06-26 11:58:24', ''),
(57, 59, 'Cash', '5.00', '0.00', 0, 1, '2023-06-26 12:00:33', ''),
(58, 59, 'Due', '5.94', '0.00', 0, 1, '2023-06-26 12:00:33', ''),
(59, 60, 'Cash', '10.00', '3.50', 0, 1, '2023-06-26 12:02:36', '');

-- --------------------------------------------------------

--
-- Table structure for table `ospos_sales_reward_points`
--

CREATE TABLE `ospos_sales_reward_points` (
  `id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `earned` float NOT NULL,
  `used` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ospos_sales_taxes`
--

CREATE TABLE `ospos_sales_taxes` (
  `sales_taxes_id` int(11) NOT NULL,
  `sale_id` int(10) NOT NULL,
  `jurisdiction_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  `tax_type` smallint(2) NOT NULL,
  `tax_group` varchar(32) NOT NULL,
  `sale_tax_basis` decimal(15,4) NOT NULL,
  `sale_tax_amount` decimal(15,4) NOT NULL,
  `print_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL,
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `rounding_code` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_sales_taxes`
--

INSERT INTO `ospos_sales_taxes` (`sales_taxes_id`, `sale_id`, `jurisdiction_id`, `tax_category_id`, `tax_type`, `tax_group`, `sale_tax_basis`, `sale_tax_amount`, `print_sequence`, `name`, `tax_rate`, `sales_tax_code_id`, `rounding_code`) VALUES
(1, 43, NULL, NULL, 1, 'vat', '6.7500', '0.7400', 1, 'vat', '11.0000', NULL, 1),
(2, 44, 2, 2, 0, 'VAT_I', '2.0000', '0.2000', 0, 'VAT_I', '11.0000', 2, 1),
(3, 44, 1, 1, 1, 'VAT_E', '2.2500', '0.2500', 1, 'VAT_E', '11.0000', 2, 1),
(4, 51, 1, 1, 1, 'VAT_E', '8.0000', '0.8800', 1, 'VAT_E', '11.0000', 2, 1),
(5, 52, 1, 1, 1, 'VAT_E', '24.0000', '2.6400', 1, 'VAT_E', '11.0000', 2, 1),
(6, 53, 1, 1, 1, 'VAT_E', '8.0000', '0.8800', 1, 'VAT_E', '11.0000', 2, 1),
(7, 54, 1, 1, 1, 'VAT_E', '4.0000', '0.4400', 1, 'VAT_E', '11.0000', 2, 1),
(8, 55, 1, 1, 1, 'VAT_E', '4.0000', '0.4400', 1, 'VAT_E', '11.0000', 2, 1),
(9, 56, 2, 2, 0, 'VAT_I', '2.0000', '0.2000', 0, 'VAT_I', '11.0000', 2, 1),
(10, 57, 1, 1, 1, 'VAT_E', '1.8000', '0.2000', 1, 'VAT_E', '11.0000', 2, 1),
(11, 58, 1, 1, 1, 'VAT_E', '4.0000', '0.4400', 1, 'VAT_E', '11.0000', 2, 1),
(12, 59, 1, 1, 1, 'VAT_E', '4.0000', '0.4400', 1, 'VAT_E', '11.0000', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_sessions`
--

CREATE TABLE `ospos_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `data` mediumblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_sessions`
--

INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('497g6numgvvc0mko3r9j9mvldl3qtlev', '127.0.0.1', 1687536048, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373533363034383b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a303a7b7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f6c6f636174696f6e7c733a313a2231223b73616c65735f7061796d656e74737c613a303a7b7d),
('h6i6r2duu8q15flchkmrjgssojkhioe1', '127.0.0.1', 1687536419, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373533363431393b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a303a7b7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f6c6f636174696f6e7c733a313a2231223b73616c65735f7061796d656e74737c613a303a7b7d),
('1c8eo5ai35kkh3u6a3m1ehhlct6skhdm', '127.0.0.1', 1687536757, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373533363735373b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a363a2231362e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f6c6f636174696f6e7c733a313a2231223b73616c65735f7061796d656e74737c613a303a7b7d),
('mneqbj47b0vj00rpnsem20akhujvf1m8', '127.0.0.1', 1687537066, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373533373036363b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a363a2231362e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f6c6f636174696f6e7c733a313a2231223b73616c65735f7061796d656e74737c613a303a7b7d6974656d5f6c6f636174696f6e7c733a313a2231223b726563765f636172747c613a303a7b7d726563765f6d6f64657c733a373a2272656365697665223b726563765f73746f636b5f736f757263657c733a313a2231223b726563765f73746f636b5f64657374696e6174696f6e7c733a313a2231223b726563765f737570706c6965727c693a2d313b),
('a32di117mesa4m6v56b5ov2ikg67d835', '127.0.0.1', 1687537454, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373533373435343b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a363a2231362e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f6c6f636174696f6e7c733a313a2231223b73616c65735f7061796d656e74737c613a303a7b7d6974656d5f6c6f636174696f6e7c733a313a2231223b726563765f636172747c613a303a7b7d726563765f6d6f64657c733a373a2272656365697665223b726563765f73746f636b5f736f757263657c733a313a2231223b726563765f73746f636b5f64657374696e6174696f6e7c733a313a2231223b726563765f737570706c6965727c693a2d313b),
('na7kucvi7i6jco0iq907rg4mvrt0nmud', '127.0.0.1', 1687537759, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373533373735393b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b726563765f636172747c613a303a7b7d726563765f6d6f64657c733a373a2272656365697665223b726563765f73746f636b5f736f757263657c733a313a2231223b726563765f73746f636b5f64657374696e6174696f6e7c733a313a2231223b726563765f737570706c6965727c693a2d313b),
('h10hs4rtjcaraqfd1hbrq9lrh0mkddn4', '127.0.0.1', 1687538076, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373533383037363b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b726563765f636172747c613a303a7b7d726563765f6d6f64657c733a373a2272656365697665223b726563765f73746f636b5f736f757263657c733a313a2231223b726563765f73746f636b5f64657374696e6174696f6e7c733a313a2231223b726563765f737570706c6965727c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f636172747c613a303a7b7d73616c65735f637573746f6d65727c693a2d313b73616c65735f7061796d656e74737c613a303a7b7d),
('cl4svcgb24j9qutiksmepd9aepq6g821', '127.0.0.1', 1687539226, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373533393232363b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b726563765f636172747c613a303a7b7d726563765f6d6f64657c733a373a2272656365697665223b726563765f73746f636b5f736f757263657c733a313a2231223b726563765f73746f636b5f64657374696e6174696f6e7c733a313a2231223b726563765f737570706c6965727c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f6d6f64657c733a343a2273616c65223b),
('63frt779lt4u9aahc9mstj2go2e6b8sv', '127.0.0.1', 1687539722, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373533393732323b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b726563765f636172747c613a303a7b7d726563765f6d6f64657c733a373a2272656365697665223b726563765f73746f636b5f736f757263657c733a313a2231223b726563765f73746f636b5f64657374696e6174696f6e7c733a313a2231223b726563765f737570706c6965727c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a363a2231352e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f7061796d656e74737c613a313a7b733a383a22d986d982d8afd989223b613a343a7b733a31323a227061796d656e745f74797065223b733a383a22d986d982d8afd989223b733a31343a227061796d656e745f616d6f756e74223b643a323b733a31313a22636173685f726566756e64223b693a303b733a31353a22636173685f61646a7573746d656e74223b693a303b7d7d),
('qsnibafthf9u57p9537blbtqjkvpsnt5', '127.0.0.1', 1687540565, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373534303536353b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b726563765f636172747c613a303a7b7d726563765f6d6f64657c733a373a2272656365697665223b726563765f73746f636b5f736f757263657c733a313a2231223b726563765f73746f636b5f64657374696e6174696f6e7c733a313a2231223b726563765f737570706c6965727c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a363a2231352e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f7061796d656e74737c613a303a7b7d),
('43a3lnt3rje5k9li7b7u4dhe2sch21t5', '127.0.0.1', 1687540989, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373534303938393b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b726563765f636172747c613a303a7b7d726563765f6d6f64657c733a373a2272656365697665223b726563765f73746f636b5f736f757263657c733a313a2231223b726563765f73746f636b5f64657374696e6174696f6e7c733a313a2231223b726563765f737570706c6965727c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a363a2231352e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f7061796d656e74737c613a303a7b7d),
('dgnbn9kaptr3jtveac0oe9r8bgvall31', '127.0.0.1', 1687541511, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373534313531313b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b726563765f636172747c613a303a7b7d726563765f6d6f64657c733a373a2272656365697665223b726563765f73746f636b5f736f757263657c733a313a2231223b726563765f73746f636b5f64657374696e6174696f6e7c733a313a2231223b726563765f737570706c6965727c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a363a2231352e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f7061796d656e74737c613a303a7b7d),
('om73ar17ldeghhhp3trg8o3lpbe249f8', '127.0.0.1', 1687541825, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373534313832353b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b726563765f636172747c613a303a7b7d726563765f6d6f64657c733a373a2272656365697665223b726563765f73746f636b5f736f757263657c733a313a2231223b726563765f73746f636b5f64657374696e6174696f6e7c733a313a2231223b726563765f737570706c6965727c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a343a22302e3030223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a363a2231352e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c733a313a2234223b73616c65735f7061796d656e74737c613a313a7b733a32343a22d8a8d8b7d8a7d982d8a920d987d8afd98ad8a93a31323030223b613a343a7b733a31323a227061796d656e745f74797065223b733a32343a22d8a8d8b7d8a7d982d8a920d987d8afd98ad8a93a31323030223b733a31343a227061796d656e745f616d6f756e74223b733a343a22332e3030223b733a31313a22636173685f726566756e64223b693a303b733a31353a22636173685f61646a7573746d656e74223b693a303b7d7d73616c65735f67696674636172645f72656d61696e6465727c693a303b),
('9o7emb7h7bf0q5aninc9p3hpq3q0i9i6', '127.0.0.1', 1687542358, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373534323335383b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b726563765f636172747c613a303a7b7d726563765f6d6f64657c733a373a2272656365697665223b726563765f73746f636b5f736f757263657c733a313a2231223b726563765f73746f636b5f64657374696e6174696f6e7c733a313a2231223b726563765f737570706c6965727c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2233223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a31373a2270657073695f756e73746f636b61626c65223b733a31313a226974656d5f6e756d626572223b733a313a2233223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22332e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2231223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('5r4b0a5nopq6m6ba89d66762vj8ud1q0', '127.0.0.1', 1687542736, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373534323733363b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b726563765f636172747c613a303a7b7d726563765f6d6f64657c733a373a2272656365697665223b726563765f73746f636b5f736f757263657c733a313a2231223b726563765f73746f636b5f64657374696e6174696f6e7c733a313a2231223b726563765f737570706c6965727c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2233223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a31373a2270657073695f756e73746f636b61626c65223b733a31313a226974656d5f6e756d626572223b733a313a2233223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22332e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2231223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('k43qkhaj0nkd6fnhvaqekh26ncdbpj52', '127.0.0.1', 1687543701, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373534333730313b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b726563765f636172747c613a303a7b7d726563765f6d6f64657c733a373a2272656365697665223b726563765f73746f636b5f736f757263657c733a313a2231223b726563765f73746f636b5f64657374696e6174696f6e7c733a313a2231223b726563765f737570706c6965727c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2233223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a31373a2270657073695f756e73746f636b61626c65223b733a31313a226974656d5f6e756d626572223b733a313a2233223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22332e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2231223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('hs5010cq8sf1b73o65236sf5lparoj17', '127.0.0.1', 1687544045, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373534343034353b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b726563765f636172747c613a303a7b7d726563765f6d6f64657c733a373a2272656365697665223b726563765f73746f636b5f736f757263657c733a313a2231223b726563765f73746f636b5f64657374696e6174696f6e7c733a313a2231223b726563765f737570706c6965727c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2233223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a31373a2270657073695f756e73746f636b61626c65223b733a31313a226974656d5f6e756d626572223b733a313a2233223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22332e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2231223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('76rv8g5r2il58kadvgu6ei9t3qqv7tip', '127.0.0.1', 1687544431, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373534343433313b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b726563765f636172747c613a303a7b7d726563765f6d6f64657c733a373a2272656365697665223b726563765f73746f636b5f736f757263657c733a313a2231223b726563765f73746f636b5f64657374696e6174696f6e7c733a313a2231223b726563765f737570706c6965727c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2233223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a31373a2270657073695f756e73746f636b61626c65223b733a31313a226974656d5f6e756d626572223b733a313a2233223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22332e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2231223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('m83d118bhd7h97l7b0mm820a6snmt2h4', '127.0.0.1', 1687544812, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373534343831323b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b726563765f636172747c613a303a7b7d726563765f6d6f64657c733a373a2272656365697665223b726563765f73746f636b5f736f757263657c733a313a2231223b726563765f73746f636b5f64657374696e6174696f6e7c733a313a2231223b726563765f737570706c6965727c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2233223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a31373a2270657073695f756e73746f636b61626c65223b733a31313a226974656d5f6e756d626572223b733a313a2233223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22332e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2231223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('fg1h27jni12ut57sq8cgqsdl43edl62j', '127.0.0.1', 1687545115, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373534353131353b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b726563765f636172747c613a303a7b7d726563765f6d6f64657c733a373a2272656365697665223b726563765f73746f636b5f736f757263657c733a313a2231223b726563765f73746f636b5f64657374696e6174696f6e7c733a313a2231223b726563765f737570706c6965727c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a303a7b7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('9ip6jiajoupa01c5lmeif903k14hsn60', '127.0.0.1', 1687545327, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373534353131353b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b726563765f636172747c613a303a7b7d726563765f6d6f64657c733a373a2272656365697665223b726563765f73746f636b5f736f757263657c733a313a2231223b726563765f73746f636b5f64657374696e6174696f6e7c733a313a2231223b726563765f737570706c6965727c693a2d313b73616c65735f656d706c6f7965657c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a303a7b7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('28noikjsbd1e1t22u9dh05iom4dp5ebr', '127.0.0.1', 1687626717, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373632363731373b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a363a226f6666696365223b616c6c6f775f74656d705f6974656d737c693a303b6974656d5f6c6f636174696f6e7c733a313a2231223b),
('e40b3f9mkjkgv51ccdjmtgqe6o9ig10o', '127.0.0.1', 1687629933, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373632393933333b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b6974656d5f6c6f636174696f6e7c733a313a2231223b73616c655f69647c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a303a7b7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f6c6f636174696f6e7c733a313a2231223b73616c655f747970657c693a303b73616c65735f7061796d656e74737c613a303a7b7d),
('ikbsc33qr8m7mhb8a7rf3242jhmqvi6r', '127.0.0.1', 1687631408, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373633313430383b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b6974656d5f6c6f636174696f6e7c733a313a2231223b73616c655f69647c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a303a7b7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f6c6f636174696f6e7c733a313a2231223b73616c655f747970657c693a303b73616c65735f7061796d656e74737c613a303a7b7d),
('0lbu7nin2onqkh1lth135demskkdpqgq', '127.0.0.1', 1687631554, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373633313430383b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a303b6974656d5f6c6f636174696f6e7c733a313a2231223b73616c655f69647c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a303a7b7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f6c6f636174696f6e7c733a313a2231223b73616c655f747970657c693a303b73616c65735f7061796d656e74737c613a303a7b7d),
('1pniog3nj8a63k8uu1k4272214632cpv', '127.0.0.1', 1687718079, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373731383037393b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a363a2231322e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('8k6fni4vivcptou6ju152nsl3hvsovhp', '127.0.0.1', 1687718940, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373731383934303b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b643a363b733a383a22646973636f756e74223b643a303b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a363a2231322e303030223b733a353a227072696365223b643a343b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a373a2232342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a373a2232342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('thh89cd1tt89nuk2t3io6gle6rgma6u1', '127.0.0.1', 1687719279, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373731393237393b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b733a363a22322e30303030223b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22362e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22382e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22382e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('stp0dkh4eeq5h9gilkfv98enn3mj988e', '127.0.0.1', 1687719594, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373731393539343b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b643a323b733a383a22646973636f756e74223b643a303b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22362e303030223b733a353a227072696365223b643a343b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22382e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22382e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('u2givhcfbiuf9v3k0leg0jn06lbnb0a4', '127.0.0.1', 1687720033, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373732303033333b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b643a323b733a383a22646973636f756e74223b643a303b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22362e303030223b733a353a227072696365223b643a343b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22382e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22382e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('p39st2da0flrglgksc8k27a6laf3u073', '127.0.0.1', 1687720501, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373732303530313b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b643a323b733a383a22646973636f756e74223b643a303b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22362e303030223b733a353a227072696365223b643a343b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22382e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22382e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d);
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('b0pon8bvpfco5kkjldibc7ssgti0pt2t', '127.0.0.1', 1687720882, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373732303838323b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b643a323b733a383a22646973636f756e74223b643a303b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22362e303030223b733a353a227072696365223b643a343b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22382e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22382e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('1qcpqk93ok2kq2viavgr6jr6suj6e3vb', '127.0.0.1', 1687721655, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373732313635353b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b643a323b733a383a22646973636f756e74223b643a303b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22362e303030223b733a353a227072696365223b643a343b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22382e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22382e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('4pdjkimc8dtg0d25elaq0iindup6r191', '127.0.0.1', 1687722016, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373732323031363b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b643a323b733a383a22646973636f756e74223b643a303b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22362e303030223b733a353a227072696365223b643a343b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22382e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22382e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('mgseh625tm6ejslf6i34jvbu2qpq5gco', '127.0.0.1', 1687722319, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373732323331393b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b643a323b733a383a22646973636f756e74223b643a303b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22362e303030223b733a353a227072696365223b643a343b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22382e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22382e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('84t0i00e4o9gukevfp148v96tc4mg098', '127.0.0.1', 1687722724, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373732323732343b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b643a323b733a383a22646973636f756e74223b643a303b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22362e303030223b733a353a227072696365223b643a343b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22382e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22382e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('6i8akclhd56gigch19sagmpnaeh3l14p', '127.0.0.1', 1687723088, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373732333038383b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a303a7b7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('ah6ec3qgd81r9d4vblmr6hdhafb4r750', '127.0.0.1', 1687723451, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373732333435313b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a333a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a343a22302e3030223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22342e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d693a323b613a32353a7b733a373a226974656d5f6964223b733a313a2232223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a323b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2232223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a343a22302e3030223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a373a222d32332e303030223b733a353a227072696365223b733a343a22322e3530223b733a31303a22636f73745f7072696365223b733a343a22312e3030223b733a353a22746f74616c223b733a363a22322e35303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22322e35303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d693a333b613a32353a7b733a373a226974656d5f6964223b733a313a2233223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a333b733a343a226e616d65223b733a31373a2270657073695f756e73746f636b61626c65223b733a31313a226974656d5f6e756d626572223b733a313a2233223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b733a363a22352e30303030223b733a383a22646973636f756e74223b733a343a22302e3030223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22332e3030223b733a353a22746f74616c223b733a373a2232302e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a373a2232302e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2231223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c733a313a2234223b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a313a7b733a333a22447565223b613a343a7b733a31323a227061796d656e745f74797065223b733a333a22447565223b733a31343a227061796d656e745f616d6f756e74223b643a352e323b733a31313a22636173685f726566756e64223b693a303b733a31353a22636173685f61646a7573746d656e74223b693a303b7d7d),
('7ag6q0jkkj392rihuqb5fiskoef3079h', '127.0.0.1', 1687773775, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373737333737353b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a303a7b7d73616c65735f637573746f6d65727c733a313a2234223b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('5rh53ab9mmc6f3ces7u7un27lhpa8bov', '127.0.0.1', 1687775018, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373737353031383b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a303a7b7d73616c65735f637573746f6d65727c733a313a2234223b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('dth3dn6hm75fp8h528ja90hskk0t42jd', '127.0.0.1', 1687776393, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373737363339333b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f6d6f64657c733a343a2273616c65223b),
('gvp1baqlpk3fv151edre95rui646g4lj', '127.0.0.1', 1687776065, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373737363036353b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a303a7b7d73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d73616c65735f637573746f6d65727c693a2d313b),
('83g7tevqsd0tfis6kgvcf3rpv2j0ara8', '127.0.0.1', 1687776696, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373737363639363b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a303b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f636172747c613a303a7b7d73616c65735f637573746f6d65727c693a2d313b73616c65735f7061796d656e74737c613a303a7b7d6974656d5f6c6f636174696f6e7c733a313a2231223b),
('9fne3c0v9gc8dqrvie4r0g9lqphsfedl', '127.0.0.1', 1687777609, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373737373630393b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a303b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f636172747c613a303a7b7d73616c65735f637573746f6d65727c693a2d313b73616c65735f7061796d656e74737c613a303a7b7d6974656d5f6c6f636174696f6e7c733a313a2231223b),
('0ieg7iufmaalu3unievv591dorn0ka7q', '127.0.0.1', 1687778299, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373737383239393b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f636172747c613a303a7b7d73616c65735f637573746f6d65727c693a2d313b73616c65735f7061796d656e74737c613a303a7b7d6974656d5f6c6f636174696f6e7c733a313a2231223b),
('qt36huadb4ispgsf8ous5oqhbb3ikacq', '127.0.0.1', 1687779895, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373737393839353b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b),
('ocifnl6dk4oc8riffbgreln43kvblht5', '127.0.0.1', 1687780238, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373738303233383b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a323a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22322e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d693a323b613a32353a7b733a373a226974656d5f6964223b733a313a2232223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a323b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2232223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a373a222d32352e303030223b733a353a227072696365223b733a343a22322e3530223b733a31303a22636f73745f7072696365223b733a343a22312e3030223b733a353a22746f74616c223b733a363a22322e35303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22322e35303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('7s3dpjp84iogkqavvf38euhoqqjt7iq8', '127.0.0.1', 1687780553, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373738303535333b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a363a226f6666696365223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a323a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22322e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d693a323b613a32353a7b733a373a226974656d5f6964223b733a313a2232223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a323b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2232223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a373a222d32352e303030223b733a353a227072696365223b733a343a22322e3530223b733a31303a22636f73745f7072696365223b733a343a22312e3030223b733a353a22746f74616c223b733a363a22322e35303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22322e35303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('98a0s72cjsgg3mt0ebp6m249e2p7kpim', '127.0.0.1', 1687780946, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373738303934363b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a303a7b7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('4tj17rl7b3bi26p6ck5l43290v0atb1n', '127.0.0.1', 1687781876, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373738313837363b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a303a7b7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('hnn8ce7mfriibptt6kaele50onmjm958', '127.0.0.1', 1687782885, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373738323838353b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a333a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d693a323b613a32353a7b733a373a226974656d5f6964223b733a313a2232223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a323b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2232223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a373a222d32382e303030223b733a353a227072696365223b733a343a22322e3530223b733a31303a22636f73745f7072696365223b733a343a22312e3030223b733a353a22746f74616c223b733a363a22322e35303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22322e35303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d693a333b613a32353a7b733a373a226974656d5f6964223b733a313a2233223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a333b733a343a226e616d65223b733a31373a2270657073695f756e73746f636b61626c65223b733a31313a226974656d5f6e756d626572223b733a313a2233223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22332e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2231223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('1qcbnmll4jl2pl507flfaops9fgnmhvt', '127.0.0.1', 1687783393, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373738333339333b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a333a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d693a323b613a32353a7b733a373a226974656d5f6964223b733a313a2232223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a323b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2232223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a373a222d32382e303030223b733a353a227072696365223b733a343a22322e3530223b733a31303a22636f73745f7072696365223b733a343a22312e3030223b733a353a22746f74616c223b733a363a22322e35303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22322e35303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d693a333b613a32353a7b733a373a226974656d5f6964223b733a313a2233223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a333b733a343a226e616d65223b733a31373a2270657073695f756e73746f636b61626c65223b733a31313a226974656d5f6e756d626572223b733a313a2233223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22332e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2231223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('kk7vpvrkodrbi0q44ef5s5l6i229vl6e', '127.0.0.1', 1687783702, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373738333730323b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a333a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d693a323b613a32353a7b733a373a226974656d5f6964223b733a313a2232223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a323b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2232223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a373a222d32382e303030223b733a353a227072696365223b733a343a22322e3530223b733a31303a22636f73745f7072696365223b733a343a22312e3030223b733a353a22746f74616c223b733a363a22322e35303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22322e35303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d693a333b613a32353a7b733a373a226974656d5f6964223b733a313a2233223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a333b733a343a226e616d65223b733a31373a2270657073695f756e73746f636b61626c65223b733a31313a226974656d5f6e756d626572223b733a313a2233223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22332e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2231223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('gev92bcioojo4ofb6imdhssum6arnv8s', '127.0.0.1', 1687784272, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373738343237323b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b73616c65735f6c6f636174696f6e7c733a313a2231223b6974656d5f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a333a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d693a323b613a32353a7b733a373a226974656d5f6964223b733a313a2232223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a323b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2232223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a373a222d32382e303030223b733a353a227072696365223b733a343a22322e3530223b733a31303a22636f73745f7072696365223b733a343a22312e3030223b733a353a22746f74616c223b733a363a22322e35303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22322e35303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d693a333b613a32353a7b733a373a226974656d5f6964223b733a313a2233223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a333b733a343a226e616d65223b733a31373a2270657073695f756e73746f636b61626c65223b733a31313a226974656d5f6e756d626572223b733a313a2233223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22332e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2231223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f7061796d656e74737c613a303a7b7d),
('c8os62ljkoulk4i20qjj7jtk83sb4kge', '127.0.0.1', 1687784850, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373738343835303b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a363a226f6666696365223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b6974656d5f6c6f636174696f6e7c733a313a2231223b),
('7k31q4u879qfb6cavdvponar788jcshu', '127.0.0.1', 1687785632, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373738353633323b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a363a226f6666696365223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b6974656d5f6c6f636174696f6e7c733a313a2231223b);
INSERT INTO `ospos_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('fpolj4hv0rkn2ccp87qqqarneeaopmnn', '127.0.0.1', 1687786205, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373738363230353b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a363a226f6666696365223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b6974656d5f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a333a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d693a323b613a32353a7b733a373a226974656d5f6964223b733a313a2232223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a323b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2232223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a373a222d32382e303030223b733a353a227072696365223b733a343a22322e3530223b733a31303a22636f73745f7072696365223b733a343a22312e3030223b733a353a22746f74616c223b733a363a22322e35303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22322e35303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d693a333b613a32353a7b733a373a226974656d5f6964223b733a313a2233223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a333b733a343a226e616d65223b733a31373a2270657073695f756e73746f636b61626c65223b733a31313a226974656d5f6e756d626572223b733a313a2233223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22332e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2231223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f6c6f636174696f6e7c733a313a2231223b73616c65735f7061796d656e74737c613a303a7b7d),
('201n94o5k409s5itlecv0g5ii72ov517', '127.0.0.1', 1687786679, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373738363637393b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a363a226f6666696365223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b6974656d5f6c6f636174696f6e7c733a313a2231223b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a333a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d693a323b613a32353a7b733a373a226974656d5f6964223b733a313a2232223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a323b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2232223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a373a222d32382e303030223b733a353a227072696365223b733a343a22322e3530223b733a31303a22636f73745f7072696365223b733a343a22312e3030223b733a353a22746f74616c223b733a363a22322e35303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22322e35303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d693a333b613a32353a7b733a373a226974656d5f6964223b733a313a2233223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a333b733a343a226e616d65223b733a31373a2270657073695f756e73746f636b61626c65223b733a31313a226974656d5f6e756d626572223b733a313a2233223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22332e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2231223b733a393a226974656d5f74797065223b733a313a2230223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b733a313a2230223b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f6c6f636174696f6e7c733a313a2231223b73616c65735f7061796d656e74737c613a303a7b7d),
('ghlqpgp1f7gjbv6cm0bfabhdfd40groo', '127.0.0.1', 1687786734, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373738363733343b),
('siqtc7a19n85mstopor8jitcoh248h22', '127.0.0.1', 1687786734, ''),
('8tod5lq3371pm3fpfoatbto7o586fb19', '127.0.0.1', 1687787138, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373738373133383b),
('tgvoipq38abfj5cpkl3nfljcgvmrfl5p', '127.0.0.1', 1687787512, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373738373531323b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b),
('5k48qal79uou0ehg0c2047eq7ci1b6pk', '127.0.0.1', 1687789810, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373738393831303b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b),
('vss1b7cktg2pbc9etqrkiemae52vd5i8', '127.0.0.1', 1687790358, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373739303335383b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b693a313b733a383a22646973636f756e74223b733a313a2230223b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b733a343a22342e3030223b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a363a22342e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a363a22342e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f6d6f64657c733a343a2273616c65223b73616c65735f6c6f636174696f6e7c733a313a2231223b73616c65735f7061796d656e74737c613a303a7b7d),
('bo9guu6u4641174sab7691vq5646opnd', '127.0.0.1', 1687790520, 0x5f5f63695f6c6173745f726567656e65726174657c693a313638373739303335383b706572736f6e5f69647c733a313a2231223b6d656e755f67726f75707c733a343a22686f6d65223b616c6c6f775f74656d705f6974656d737c693a313b73616c655f69647c693a2d313b636173685f726f756e64696e677c693a303b636173685f6d6f64657c693a303b73616c65735f6d6f64657c733a363a2272657475726e223b73616c65735f6c6f636174696f6e7c733a313a2231223b73616c655f747970657c693a343b73616c65735f636172747c613a313a7b693a313b613a32353a7b733a373a226974656d5f6964223b733a313a2231223b733a31333a226974656d5f6c6f636174696f6e223b733a313a2231223b733a31303a2273746f636b5f6e616d65223b733a363a2273746f636b31223b733a343a226c696e65223b693a313b733a343a226e616d65223b733a343a22636f6c61223b733a31313a226974656d5f6e756d626572223b733a313a2231223b733a31363a226174747269627574655f76616c756573223b4e3b733a31383a226174747269627574655f647476616c756573223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a31323a2273657269616c6e756d626572223b733a303a22223b733a32313a22616c6c6f775f616c745f6465736372697074696f6e223b733a313a2230223b733a31333a2269735f73657269616c697a6564223b733a313a2230223b733a383a227175616e74697479223b643a2d31303b733a383a22646973636f756e74223b643a303b733a31333a22646973636f756e745f74797065223b733a313a2230223b733a383a22696e5f73746f636b223b733a353a22302e303030223b733a353a227072696365223b643a393b733a31303a22636f73745f7072696365223b733a343a22322e3030223b733a353a22746f74616c223b733a383a222d39302e30303030223b733a31363a22646973636f756e7465645f746f74616c223b733a383a222d39302e30303030223b733a31323a227072696e745f6f7074696f6e223b693a303b733a31303a2273746f636b5f74797065223b733a313a2230223b733a393a226974656d5f74797065223b733a313a2231223b733a383a2268736e5f636f6465223b733a303a22223b733a31353a227461785f63617465676f72795f6964223b4e3b7d7d73616c65735f637573746f6d65727c693a2d313b73616c65735f7061796d656e74737c613a303a7b7d);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_stock_locations`
--

CREATE TABLE `ospos_stock_locations` (
  `location_id` int(11) NOT NULL,
  `location_name` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_stock_locations`
--

INSERT INTO `ospos_stock_locations` (`location_id`, `location_name`, `deleted`) VALUES
(1, 'stock1', 0),
(2, 'stock2', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_suppliers`
--

CREATE TABLE `ospos_suppliers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `agency_name` varchar(255) NOT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `tax_id` varchar(32) NOT NULL DEFAULT '',
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `category` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ospos_tax_categories`
--

CREATE TABLE `ospos_tax_categories` (
  `tax_category_id` int(10) NOT NULL,
  `tax_category` varchar(32) NOT NULL,
  `tax_group_sequence` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_tax_categories`
--

INSERT INTO `ospos_tax_categories` (`tax_category_id`, `tax_category`, `tax_group_sequence`, `deleted`) VALUES
(1, 'vat-Excluded', 1, 0),
(2, 'vat-Included', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_tax_codes`
--

CREATE TABLE `ospos_tax_codes` (
  `tax_code_id` int(11) NOT NULL,
  `tax_code` varchar(32) NOT NULL,
  `tax_code_name` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(255) NOT NULL DEFAULT '',
  `deleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_tax_codes`
--

INSERT INTO `ospos_tax_codes` (`tax_code_id`, `tax_code`, `tax_code_name`, `city`, `state`, `deleted`) VALUES
(1, '11', 'vat', 'Beirut', 'baabda', 1),
(2, '1122', 'vat', 'Beirut', 'baabda', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_tax_jurisdictions`
--

CREATE TABLE `ospos_tax_jurisdictions` (
  `jurisdiction_id` int(11) NOT NULL,
  `jurisdiction_name` varchar(255) DEFAULT NULL,
  `tax_group` varchar(32) NOT NULL,
  `tax_type` smallint(2) NOT NULL,
  `reporting_authority` varchar(255) DEFAULT NULL,
  `tax_group_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `cascade_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_tax_jurisdictions`
--

INSERT INTO `ospos_tax_jurisdictions` (`jurisdiction_id`, `jurisdiction_name`, `tax_group`, `tax_type`, `reporting_authority`, `tax_group_sequence`, `cascade_sequence`, `deleted`) VALUES
(1, 'Lebanese goverment Exculded', 'VAT_E', 1, '', 0, 0, 0),
(2, 'Lebanese goverment Included', 'VAT_I', 0, '', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ospos_tax_rates`
--

CREATE TABLE `ospos_tax_rates` (
  `tax_rate_id` int(11) NOT NULL,
  `rate_tax_code_id` int(11) NOT NULL,
  `rate_tax_category_id` int(10) NOT NULL,
  `rate_jurisdiction_id` int(11) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `tax_rounding_code` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ospos_tax_rates`
--

INSERT INTO `ospos_tax_rates` (`tax_rate_id`, `rate_tax_code_id`, `rate_tax_category_id`, `rate_jurisdiction_id`, `tax_rate`, `tax_rounding_code`) VALUES
(1, 2, 1, 1, '11.0000', 1),
(2, 2, 2, 2, '11.0000', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pos_global_variables`
--

CREATE TABLE `pos_global_variables` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `value_int` int(11) DEFAULT NULL,
  `value_txt` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pos_global_variables`
--

INSERT INTO `pos_global_variables` (`id`, `name`, `value_int`, `value_txt`) VALUES
(1, 'dollar_rate', 92000, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ospos_app_config`
--
ALTER TABLE `ospos_app_config`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `ospos_attribute_definitions`
--
ALTER TABLE `ospos_attribute_definitions`
  ADD PRIMARY KEY (`definition_id`),
  ADD KEY `definition_fk` (`definition_fk`),
  ADD KEY `definition_name` (`definition_name`),
  ADD KEY `definition_type` (`definition_type`);

--
-- Indexes for table `ospos_attribute_links`
--
ALTER TABLE `ospos_attribute_links`
  ADD UNIQUE KEY `attribute_links_uq1` (`attribute_id`,`definition_id`,`item_id`,`sale_id`,`receiving_id`),
  ADD UNIQUE KEY `attribute_links_uq2` (`item_id`,`sale_id`,`receiving_id`,`definition_id`,`attribute_id`),
  ADD KEY `attribute_id` (`attribute_id`),
  ADD KEY `definition_id` (`definition_id`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `sale_id` (`sale_id`),
  ADD KEY `receiving_id` (`receiving_id`);

--
-- Indexes for table `ospos_attribute_values`
--
ALTER TABLE `ospos_attribute_values`
  ADD PRIMARY KEY (`attribute_id`),
  ADD UNIQUE KEY `attribute_value` (`attribute_value`),
  ADD UNIQUE KEY `attribute_date` (`attribute_date`),
  ADD UNIQUE KEY `attribute_decimal` (`attribute_decimal`);

--
-- Indexes for table `ospos_cash_up`
--
ALTER TABLE `ospos_cash_up`
  ADD PRIMARY KEY (`cashup_id`),
  ADD KEY `open_employee_id` (`open_employee_id`),
  ADD KEY `close_employee_id` (`close_employee_id`);

--
-- Indexes for table `ospos_customers`
--
ALTER TABLE `ospos_customers`
  ADD PRIMARY KEY (`person_id`),
  ADD UNIQUE KEY `account_number` (`account_number`),
  ADD KEY `person_id` (`person_id`),
  ADD KEY `package_id` (`package_id`),
  ADD KEY `sales_tax_code_id` (`sales_tax_code_id`),
  ADD KEY `company_name` (`company_name`);

--
-- Indexes for table `ospos_customers_packages`
--
ALTER TABLE `ospos_customers_packages`
  ADD PRIMARY KEY (`package_id`);

--
-- Indexes for table `ospos_customers_points`
--
ALTER TABLE `ospos_customers_points`
  ADD PRIMARY KEY (`id`),
  ADD KEY `person_id` (`person_id`),
  ADD KEY `package_id` (`package_id`),
  ADD KEY `sale_id` (`sale_id`);

--
-- Indexes for table `ospos_dinner_tables`
--
ALTER TABLE `ospos_dinner_tables`
  ADD PRIMARY KEY (`dinner_table_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `ospos_employees`
--
ALTER TABLE `ospos_employees`
  ADD PRIMARY KEY (`person_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `person_id` (`person_id`);

--
-- Indexes for table `ospos_expenses`
--
ALTER TABLE `ospos_expenses`
  ADD PRIMARY KEY (`expense_id`),
  ADD KEY `expense_category_id` (`expense_category_id`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `ospos_expenses_ibfk_3` (`supplier_id`),
  ADD KEY `date` (`date`),
  ADD KEY `payment_type` (`payment_type`),
  ADD KEY `amount` (`amount`);

--
-- Indexes for table `ospos_expense_categories`
--
ALTER TABLE `ospos_expense_categories`
  ADD PRIMARY KEY (`expense_category_id`),
  ADD UNIQUE KEY `category_name` (`category_name`),
  ADD KEY `category_description` (`category_description`);

--
-- Indexes for table `ospos_giftcards`
--
ALTER TABLE `ospos_giftcards`
  ADD PRIMARY KEY (`giftcard_id`),
  ADD UNIQUE KEY `giftcard_number` (`giftcard_number`),
  ADD KEY `person_id` (`person_id`);

--
-- Indexes for table `ospos_grants`
--
ALTER TABLE `ospos_grants`
  ADD PRIMARY KEY (`permission_id`,`person_id`),
  ADD KEY `ospos_grants_ibfk_2` (`person_id`);

--
-- Indexes for table `ospos_inventory`
--
ALTER TABLE `ospos_inventory`
  ADD PRIMARY KEY (`trans_id`),
  ADD KEY `trans_items` (`trans_items`),
  ADD KEY `trans_user` (`trans_user`),
  ADD KEY `trans_location` (`trans_location`),
  ADD KEY `trans_date` (`trans_date`);

--
-- Indexes for table `ospos_items`
--
ALTER TABLE `ospos_items`
  ADD PRIMARY KEY (`item_id`),
  ADD UNIQUE KEY `items_uq1` (`supplier_id`,`item_id`,`deleted`,`item_type`),
  ADD KEY `item_number` (`item_number`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `deleted` (`deleted`,`item_type`);

--
-- Indexes for table `ospos_items_taxes`
--
ALTER TABLE `ospos_items_taxes`
  ADD PRIMARY KEY (`item_id`,`name`,`percent`);

--
-- Indexes for table `ospos_item_kits`
--
ALTER TABLE `ospos_item_kits`
  ADD PRIMARY KEY (`item_kit_id`),
  ADD KEY `item_kit_number` (`item_kit_number`),
  ADD KEY `name` (`name`,`description`);

--
-- Indexes for table `ospos_item_kit_items`
--
ALTER TABLE `ospos_item_kit_items`
  ADD PRIMARY KEY (`item_kit_id`,`item_id`,`quantity`),
  ADD KEY `ospos_item_kit_items_ibfk_2` (`item_id`);

--
-- Indexes for table `ospos_item_quantities`
--
ALTER TABLE `ospos_item_quantities`
  ADD PRIMARY KEY (`item_id`,`location_id`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `location_id` (`location_id`);

--
-- Indexes for table `ospos_modules`
--
ALTER TABLE `ospos_modules`
  ADD PRIMARY KEY (`module_id`),
  ADD UNIQUE KEY `desc_lang_key` (`desc_lang_key`),
  ADD UNIQUE KEY `name_lang_key` (`name_lang_key`);

--
-- Indexes for table `ospos_people`
--
ALTER TABLE `ospos_people`
  ADD PRIMARY KEY (`person_id`),
  ADD KEY `email` (`email`),
  ADD KEY `first_name` (`first_name`,`last_name`,`email`,`phone_number`);

--
-- Indexes for table `ospos_permissions`
--
ALTER TABLE `ospos_permissions`
  ADD PRIMARY KEY (`permission_id`),
  ADD KEY `module_id` (`module_id`),
  ADD KEY `ospos_permissions_ibfk_2` (`location_id`);

--
-- Indexes for table `ospos_receivings`
--
ALTER TABLE `ospos_receivings`
  ADD PRIMARY KEY (`receiving_id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `reference` (`reference`),
  ADD KEY `receiving_time` (`receiving_time`);

--
-- Indexes for table `ospos_receivings_items`
--
ALTER TABLE `ospos_receivings_items`
  ADD PRIMARY KEY (`receiving_id`,`item_id`,`line`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `ospos_sales`
--
ALTER TABLE `ospos_sales`
  ADD PRIMARY KEY (`sale_id`),
  ADD UNIQUE KEY `invoice_number` (`invoice_number`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `sale_time` (`sale_time`),
  ADD KEY `dinner_table_id` (`dinner_table_id`);

--
-- Indexes for table `ospos_sales_items`
--
ALTER TABLE `ospos_sales_items`
  ADD PRIMARY KEY (`sale_id`,`item_id`,`line`),
  ADD KEY `sale_id` (`sale_id`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `item_location` (`item_location`);

--
-- Indexes for table `ospos_sales_items_taxes`
--
ALTER TABLE `ospos_sales_items_taxes`
  ADD PRIMARY KEY (`sale_id`,`item_id`,`line`,`name`,`percent`),
  ADD KEY `sale_id` (`sale_id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `ospos_sales_payments`
--
ALTER TABLE `ospos_sales_payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `payment_sale` (`sale_id`,`payment_type`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `payment_time` (`payment_time`);

--
-- Indexes for table `ospos_sales_reward_points`
--
ALTER TABLE `ospos_sales_reward_points`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sale_id` (`sale_id`);

--
-- Indexes for table `ospos_sales_taxes`
--
ALTER TABLE `ospos_sales_taxes`
  ADD PRIMARY KEY (`sales_taxes_id`),
  ADD KEY `print_sequence` (`sale_id`,`print_sequence`,`tax_group`);

--
-- Indexes for table `ospos_sessions`
--
ALTER TABLE `ospos_sessions`
  ADD KEY `ci_sessions_timestamp` (`timestamp`),
  ADD KEY `id` (`id`),
  ADD KEY `ip_address` (`ip_address`);

--
-- Indexes for table `ospos_stock_locations`
--
ALTER TABLE `ospos_stock_locations`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `ospos_suppliers`
--
ALTER TABLE `ospos_suppliers`
  ADD PRIMARY KEY (`person_id`),
  ADD UNIQUE KEY `account_number` (`account_number`),
  ADD KEY `person_id` (`person_id`),
  ADD KEY `category` (`category`),
  ADD KEY `company_name` (`company_name`,`deleted`);

--
-- Indexes for table `ospos_tax_categories`
--
ALTER TABLE `ospos_tax_categories`
  ADD PRIMARY KEY (`tax_category_id`);

--
-- Indexes for table `ospos_tax_codes`
--
ALTER TABLE `ospos_tax_codes`
  ADD PRIMARY KEY (`tax_code_id`);

--
-- Indexes for table `ospos_tax_jurisdictions`
--
ALTER TABLE `ospos_tax_jurisdictions`
  ADD PRIMARY KEY (`jurisdiction_id`),
  ADD UNIQUE KEY `tax_jurisdictions_uq1` (`tax_group`);

--
-- Indexes for table `ospos_tax_rates`
--
ALTER TABLE `ospos_tax_rates`
  ADD PRIMARY KEY (`tax_rate_id`),
  ADD KEY `rate_tax_category_id` (`rate_tax_category_id`),
  ADD KEY `rate_tax_code_id` (`rate_tax_code_id`),
  ADD KEY `rate_jurisdiction_id` (`rate_jurisdiction_id`);

--
-- Indexes for table `pos_global_variables`
--
ALTER TABLE `pos_global_variables`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name_unique` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ospos_attribute_definitions`
--
ALTER TABLE `ospos_attribute_definitions`
  MODIFY `definition_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ospos_attribute_values`
--
ALTER TABLE `ospos_attribute_values`
  MODIFY `attribute_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ospos_cash_up`
--
ALTER TABLE `ospos_cash_up`
  MODIFY `cashup_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ospos_customers_packages`
--
ALTER TABLE `ospos_customers_packages`
  MODIFY `package_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ospos_customers_points`
--
ALTER TABLE `ospos_customers_points`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ospos_dinner_tables`
--
ALTER TABLE `ospos_dinner_tables`
  MODIFY `dinner_table_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ospos_expenses`
--
ALTER TABLE `ospos_expenses`
  MODIFY `expense_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ospos_expense_categories`
--
ALTER TABLE `ospos_expense_categories`
  MODIFY `expense_category_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ospos_giftcards`
--
ALTER TABLE `ospos_giftcards`
  MODIFY `giftcard_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ospos_inventory`
--
ALTER TABLE `ospos_inventory`
  MODIFY `trans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21368;

--
-- AUTO_INCREMENT for table `ospos_items`
--
ALTER TABLE `ospos_items`
  MODIFY `item_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ospos_item_kits`
--
ALTER TABLE `ospos_item_kits`
  MODIFY `item_kit_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ospos_people`
--
ALTER TABLE `ospos_people`
  MODIFY `person_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ospos_receivings`
--
ALTER TABLE `ospos_receivings`
  MODIFY `receiving_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ospos_sales`
--
ALTER TABLE `ospos_sales`
  MODIFY `sale_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `ospos_sales_payments`
--
ALTER TABLE `ospos_sales_payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `ospos_sales_reward_points`
--
ALTER TABLE `ospos_sales_reward_points`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ospos_sales_taxes`
--
ALTER TABLE `ospos_sales_taxes`
  MODIFY `sales_taxes_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `ospos_stock_locations`
--
ALTER TABLE `ospos_stock_locations`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ospos_tax_categories`
--
ALTER TABLE `ospos_tax_categories`
  MODIFY `tax_category_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ospos_tax_codes`
--
ALTER TABLE `ospos_tax_codes`
  MODIFY `tax_code_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ospos_tax_jurisdictions`
--
ALTER TABLE `ospos_tax_jurisdictions`
  MODIFY `jurisdiction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ospos_tax_rates`
--
ALTER TABLE `ospos_tax_rates`
  MODIFY `tax_rate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pos_global_variables`
--
ALTER TABLE `pos_global_variables`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ospos_attribute_definitions`
--
ALTER TABLE `ospos_attribute_definitions`
  ADD CONSTRAINT `fk_ospos_attribute_definitions_ibfk_1` FOREIGN KEY (`definition_fk`) REFERENCES `ospos_attribute_definitions` (`definition_id`);

--
-- Constraints for table `ospos_attribute_links`
--
ALTER TABLE `ospos_attribute_links`
  ADD CONSTRAINT `ospos_attribute_links_ibfk_1` FOREIGN KEY (`definition_id`) REFERENCES `ospos_attribute_definitions` (`definition_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ospos_attribute_links_ibfk_2` FOREIGN KEY (`attribute_id`) REFERENCES `ospos_attribute_values` (`attribute_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ospos_attribute_links_ibfk_3` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  ADD CONSTRAINT `ospos_attribute_links_ibfk_4` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ospos_attribute_links_ibfk_5` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`);

--
-- Constraints for table `ospos_cash_up`
--
ALTER TABLE `ospos_cash_up`
  ADD CONSTRAINT `ospos_cash_up_ibfk_1` FOREIGN KEY (`open_employee_id`) REFERENCES `ospos_employees` (`person_id`),
  ADD CONSTRAINT `ospos_cash_up_ibfk_2` FOREIGN KEY (`close_employee_id`) REFERENCES `ospos_employees` (`person_id`);

--
-- Constraints for table `ospos_customers`
--
ALTER TABLE `ospos_customers`
  ADD CONSTRAINT `ospos_customers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`),
  ADD CONSTRAINT `ospos_customers_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  ADD CONSTRAINT `ospos_customers_ibfk_3` FOREIGN KEY (`sales_tax_code_id`) REFERENCES `ospos_tax_codes` (`tax_code_id`);

--
-- Constraints for table `ospos_customers_points`
--
ALTER TABLE `ospos_customers_points`
  ADD CONSTRAINT `ospos_customers_points_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_customers` (`person_id`),
  ADD CONSTRAINT `ospos_customers_points_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  ADD CONSTRAINT `ospos_customers_points_ibfk_3` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`);

--
-- Constraints for table `ospos_employees`
--
ALTER TABLE `ospos_employees`
  ADD CONSTRAINT `ospos_employees_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`);

--
-- Constraints for table `ospos_expenses`
--
ALTER TABLE `ospos_expenses`
  ADD CONSTRAINT `ospos_expenses_ibfk_1` FOREIGN KEY (`expense_category_id`) REFERENCES `ospos_expense_categories` (`expense_category_id`),
  ADD CONSTRAINT `ospos_expenses_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  ADD CONSTRAINT `ospos_expenses_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`);

--
-- Constraints for table `ospos_giftcards`
--
ALTER TABLE `ospos_giftcards`
  ADD CONSTRAINT `ospos_giftcards_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`);

--
-- Constraints for table `ospos_grants`
--
ALTER TABLE `ospos_grants`
  ADD CONSTRAINT `ospos_grants_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `ospos_permissions` (`permission_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ospos_grants_ibfk_2` FOREIGN KEY (`person_id`) REFERENCES `ospos_employees` (`person_id`) ON DELETE CASCADE;

--
-- Constraints for table `ospos_inventory`
--
ALTER TABLE `ospos_inventory`
  ADD CONSTRAINT `ospos_inventory_ibfk_1` FOREIGN KEY (`trans_items`) REFERENCES `ospos_items` (`item_id`),
  ADD CONSTRAINT `ospos_inventory_ibfk_2` FOREIGN KEY (`trans_user`) REFERENCES `ospos_employees` (`person_id`),
  ADD CONSTRAINT `ospos_inventory_ibfk_3` FOREIGN KEY (`trans_location`) REFERENCES `ospos_stock_locations` (`location_id`);

--
-- Constraints for table `ospos_items`
--
ALTER TABLE `ospos_items`
  ADD CONSTRAINT `ospos_items_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`);

--
-- Constraints for table `ospos_items_taxes`
--
ALTER TABLE `ospos_items_taxes`
  ADD CONSTRAINT `ospos_items_taxes_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE;

--
-- Constraints for table `ospos_item_kit_items`
--
ALTER TABLE `ospos_item_kit_items`
  ADD CONSTRAINT `ospos_item_kit_items_ibfk_1` FOREIGN KEY (`item_kit_id`) REFERENCES `ospos_item_kits` (`item_kit_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ospos_item_kit_items_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE;

--
-- Constraints for table `ospos_item_quantities`
--
ALTER TABLE `ospos_item_quantities`
  ADD CONSTRAINT `ospos_item_quantities_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  ADD CONSTRAINT `ospos_item_quantities_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`);

--
-- Constraints for table `ospos_permissions`
--
ALTER TABLE `ospos_permissions`
  ADD CONSTRAINT `ospos_permissions_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `ospos_modules` (`module_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ospos_permissions_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`) ON DELETE CASCADE;

--
-- Constraints for table `ospos_receivings`
--
ALTER TABLE `ospos_receivings`
  ADD CONSTRAINT `ospos_receivings_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  ADD CONSTRAINT `ospos_receivings_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`);

--
-- Constraints for table `ospos_receivings_items`
--
ALTER TABLE `ospos_receivings_items`
  ADD CONSTRAINT `ospos_receivings_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  ADD CONSTRAINT `ospos_receivings_items_ibfk_2` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`);

--
-- Constraints for table `ospos_sales`
--
ALTER TABLE `ospos_sales`
  ADD CONSTRAINT `ospos_sales_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  ADD CONSTRAINT `ospos_sales_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `ospos_customers` (`person_id`),
  ADD CONSTRAINT `ospos_sales_ibfk_3` FOREIGN KEY (`dinner_table_id`) REFERENCES `ospos_dinner_tables` (`dinner_table_id`);

--
-- Constraints for table `ospos_sales_items`
--
ALTER TABLE `ospos_sales_items`
  ADD CONSTRAINT `ospos_sales_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  ADD CONSTRAINT `ospos_sales_items_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  ADD CONSTRAINT `ospos_sales_items_ibfk_3` FOREIGN KEY (`item_location`) REFERENCES `ospos_stock_locations` (`location_id`);

--
-- Constraints for table `ospos_sales_items_taxes`
--
ALTER TABLE `ospos_sales_items_taxes`
  ADD CONSTRAINT `ospos_sales_items_taxes_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales_items` (`sale_id`),
  ADD CONSTRAINT `ospos_sales_items_taxes_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`);

--
-- Constraints for table `ospos_sales_payments`
--
ALTER TABLE `ospos_sales_payments`
  ADD CONSTRAINT `ospos_sales_payments_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  ADD CONSTRAINT `ospos_sales_payments_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`);

--
-- Constraints for table `ospos_sales_reward_points`
--
ALTER TABLE `ospos_sales_reward_points`
  ADD CONSTRAINT `ospos_sales_reward_points_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`);

--
-- Constraints for table `ospos_suppliers`
--
ALTER TABLE `ospos_suppliers`
  ADD CONSTRAINT `ospos_suppliers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`);

--
-- Constraints for table `ospos_tax_rates`
--
ALTER TABLE `ospos_tax_rates`
  ADD CONSTRAINT `ospos_tax_rates_ibfk_1` FOREIGN KEY (`rate_tax_category_id`) REFERENCES `ospos_tax_categories` (`tax_category_id`),
  ADD CONSTRAINT `ospos_tax_rates_ibfk_2` FOREIGN KEY (`rate_tax_code_id`) REFERENCES `ospos_tax_codes` (`tax_code_id`),
  ADD CONSTRAINT `ospos_tax_rates_ibfk_3` FOREIGN KEY (`rate_jurisdiction_id`) REFERENCES `ospos_tax_jurisdictions` (`jurisdiction_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
